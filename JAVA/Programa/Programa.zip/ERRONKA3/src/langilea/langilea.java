package langilea;

public class langilea {

	private String langileIdentifikadorea;
	private String pasahitza;
	
	public langilea(String langileIdentifikadorea, String pasahitza) {
		
		this.langileIdentifikadorea=langileIdentifikadorea;
		this.pasahitza=pasahitza;
		
	}
	
	public String getLangileIdentifikadorea() {
		return langileIdentifikadorea;
	}

	public void setLangileIdentifikadorea(String langileIdentifikadorea) {
		this.langileIdentifikadorea  = langileIdentifikadorea;
	}

	@Override
	public String toString() {
		return "langilea [langileIdentifikadorea=" + langileIdentifikadorea + ", pasahitza=" + pasahitza + "]";
	}

	public String getPasahitza() {
		return pasahitza;
	}

	public void setPasahitza(String pasahitza) {
		this.pasahitza = pasahitza;
	}
	
}
