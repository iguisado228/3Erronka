package langilea;

public class langilea {

	private String langileIdentifikadorea;
	private String pasahitza;
	private int idLangilea;
	
	public langilea(String langileIdentifikadorea, String pasahitza, int idLangilea) {
		
		this.langileIdentifikadorea=langileIdentifikadorea;
		this.pasahitza=pasahitza;
		this.idLangilea=idLangilea;
		
	}
	
	public int getIdLangilea() {
		return idLangilea;
	}

	public void setIdLangilea(int idLangilea) {
		this.idLangilea = idLangilea;
	}

	public String getLangileIdentifikadorea() {
		return langileIdentifikadorea;
	}

	public void setLangileIdentifikadorea(String langileIdentifikadorea) {
		this.langileIdentifikadorea  = langileIdentifikadorea;
	}

	@Override
	public String toString() {
		return "langilea [langileIdentifikadorea=" + langileIdentifikadorea + ", pasahitza=" + pasahitza + "]";
	}

	public String getPasahitza() {
		return pasahitza;
	}

	public void setPasahitza(String pasahitza) {
		this.pasahitza = pasahitza;
	}
	
}
