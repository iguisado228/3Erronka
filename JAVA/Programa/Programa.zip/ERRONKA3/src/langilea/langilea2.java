package langilea;

public class langilea2 {

	private int idLangilea;
	private String NAN;
	private String izena;
	private String abizena;
	private String telefonoa;
	private String helbidea;
	private String lanPostua;
	private String identifikadorea;
	private String pasahitza;
	
	
	public langilea2(int idLangilea, String NAN, String izena, String abizena, String telefonoa, 
			String helbidea, String lanPostua, String identifikadorea, String pasahitza) {
		
		this.idLangilea=idLangilea;
		this.NAN=NAN;
		this.izena=izena;
		this.abizena=abizena;
		this.telefonoa=telefonoa;
		this.helbidea=helbidea;
		this.lanPostua=lanPostua;
		this.identifikadorea=identifikadorea;
		this.pasahitza=pasahitza;
		
	}

	public int getIdLangilea() {
		return idLangilea;
	}

	public void setIdLangilea(int idLangilea) {
		this.idLangilea = idLangilea;
	}

	public String getNAN() {
		return NAN;
	}

	public void setNAN(String nAN) {
		NAN = nAN;
	}

	public String getIzena() {
		return izena;
	}

	public void setIzena(String izena) {
		this.izena = izena;
	}

	public String getAbizena() {
		return abizena;
	}

	public void setAbizena(String abizena) {
		this.abizena = abizena;
	}

	public String getTelefonoa() {
		return telefonoa;
	}

	public void setTelefonoa(String telefonoa) {
		this.telefonoa = telefonoa;
	}

	public String getHelbidea() {
		return helbidea;
	}

	public void setHelbidea(String helbidea) {
		this.helbidea = helbidea;
	}

	public String getLanPostua() {
		return lanPostua;
	}

	public void setLanPostua(String lanPostua) {
		this.lanPostua = lanPostua;
	}

	public String getLangileIdentifikadorea() {
		return identifikadorea;
	}

	public void setIdentifikadorea(String identifikadorea) {
		this.identifikadorea  = identifikadorea;
	}


	public String getPasahitza() {
		return pasahitza;
	}

	public void setPasahitza(String pasahitza) {
		this.pasahitza = pasahitza;
	}
	
}
