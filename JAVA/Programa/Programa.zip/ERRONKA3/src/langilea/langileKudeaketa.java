package langilea;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import konexioa.konexioa;

public class langileKudeaketa {

    public langilea langileaLortu(langilea lan) {
        konexioa k = new konexioa();
        langilea langilea = null;
        ResultSet rs = null;
        PreparedStatement pst = null;
        Connection conn = null;

        try {
            conn = k.getConnection_();
            
            if (conn == null) {
                System.out.println("Errorea: Ezin da datu-basearekin konektatu.");
                return null;
            }

            String sql = "SELECT * FROM langilea WHERE identifikadorea = ? AND pasahitza = ?";
            pst = conn.prepareStatement(sql);
            pst.setString(1, lan.getLangileIdentifikadorea());
            pst.setString(2, lan.getPasahitza());

            rs = pst.executeQuery();

            if (rs.next()) { // Verificar si hay resultados
                langilea = new langilea(
                    rs.getString("identifikadorea"), 
                    rs.getString("pasahitza"));
            } else {
                System.out.println("Ez da langilerik aurkitu datu-basean.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Errore bat izan da SELECT egitean.");
        } 

        return langilea;
    }
}
