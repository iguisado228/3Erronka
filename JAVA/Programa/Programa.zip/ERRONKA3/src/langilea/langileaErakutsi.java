package langilea;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import konexioa.konexioa;

public class langileaErakutsi {
	
	public List<langilea2> langileaErakutsi(){
		
		List <langilea2> langileak = new ArrayList<>();
		
		konexioa k = new konexioa();
		langilea2 langilea = null;
		Connection conn = null; 
		ResultSet rs = null;
		PreparedStatement pst = null;
		
		try {
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql = "select * from langilea";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			
			while (rs.next()) {
				
				langilea2 la = new langilea2 (rs.getInt("idLangilea"), rs.getString("NAN"), rs.getString("izena"),
						 rs.getString("abizena"), rs.getString("telefonoa"), rs.getString("helbidea"), 
						 rs.getString("lanPostua"), rs.getString("identifikadorea"), rs.getString("pasahitza"));
				langileak.add(la);
				
			}
			
		} catch(Exception e) {
			
			e.printStackTrace();
			System.out.println("Errore bat izan da select-a egiterakoan");
		}
		return langileak;
	}
	
	

}
