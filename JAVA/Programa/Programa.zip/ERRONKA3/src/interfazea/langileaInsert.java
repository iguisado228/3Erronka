package interfazea;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import konexioa.konexioa;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class langileaInsert extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfNAN;
	private JTextField tfIzena;
	private JTextField tfAbizena;
	private JTextField tfTelefonoa;
	private JTextField tfHelbidea;
	private JTextField tfLanPostua;
	private JTextField tfIdentifikadorea;
	private JTextField tfPasahitza;
	
	konexioa k = new konexioa();
	Connection conn = null; 
	ResultSet rs = null;
	PreparedStatement pst = null;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					langileaInsert frame = new langileaInsert();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public langileaInsert() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 986, 563);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblTestua = new JLabel("Ondorengo eremuak bete langile berriaren datuak sartzeko");
		lblTestua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTestua.setBounds(43, 38, 563, 40);
		panel.add(lblTestua);
		
		JLabel lblNAN = new JLabel("NAN");
		lblNAN.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNAN.setBounds(115, 125, 70, 34);
		panel.add(lblNAN);
		
		JLabel lblIzena = new JLabel("IZENA");
		lblIzena.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIzena.setBounds(115, 215, 70, 34);
		panel.add(lblIzena);
		
		JLabel lblAbizena = new JLabel("ABIZENA");
		lblAbizena.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblAbizena.setBounds(115, 305, 82, 34);
		panel.add(lblAbizena);
		
		JLabel lblTelefonoa = new JLabel("TELEFONOA");
		lblTelefonoa.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTelefonoa.setBounds(115, 400, 109, 34);
		panel.add(lblTelefonoa);
		
		JLabel lblHelbidea = new JLabel("HELBIDEA");
		lblHelbidea.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblHelbidea.setBounds(524, 125, 118, 34);
		panel.add(lblHelbidea);
		
		JLabel lblLanpostua = new JLabel("LANPOSTUA");
		lblLanpostua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblLanpostua.setBounds(524, 215, 133, 34);
		panel.add(lblLanpostua);
		
		JLabel lblIdentifikadorea = new JLabel("IDENTIFIKADOREA");
		lblIdentifikadorea.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIdentifikadorea.setBounds(524, 305, 188, 34);
		panel.add(lblIdentifikadorea);
		
		JLabel lblPasahitza = new JLabel("PASAHITZA");
		lblPasahitza.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPasahitza.setBounds(524, 400, 143, 34);
		panel.add(lblPasahitza);
		
		tfNAN = new JTextField();
		tfNAN.setColumns(10);
		tfNAN.setBounds(238, 125, 151, 34);
		panel.add(tfNAN);
		
		tfIzena = new JTextField();
		tfIzena.setColumns(10);
		tfIzena.setBounds(238, 215, 151, 34);
		panel.add(tfIzena);
		
		tfAbizena = new JTextField();
		tfAbizena.setColumns(10);
		tfAbizena.setBounds(238, 305, 151, 34);
		panel.add(tfAbizena);
		
		tfTelefonoa = new JTextField();
		tfTelefonoa.setColumns(10);
		tfTelefonoa.setBounds(238, 400, 151, 34);
		panel.add(tfTelefonoa);
		
		tfHelbidea = new JTextField();
		tfHelbidea.setColumns(10);
		tfHelbidea.setBounds(752, 125, 151, 34);
		panel.add(tfHelbidea);
		
		tfLanPostua = new JTextField();
		tfLanPostua.setColumns(10);
		tfLanPostua.setBounds(752, 215, 151, 34);
		panel.add(tfLanPostua);
		
		tfIdentifikadorea = new JTextField();
		tfIdentifikadorea.setColumns(10);
		tfIdentifikadorea.setBounds(752, 305, 151, 34);
		panel.add(tfIdentifikadorea);
		
		tfPasahitza = new JTextField();
		tfPasahitza.setColumns(10);
		tfPasahitza.setBounds(752, 400, 151, 34);
		panel.add(tfPasahitza);
		
		JButton btnInsert = new JButton("INSERT");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				insertLangilea();
				
			}
		});
		btnInsert.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnInsert.setBounds(623, 38, 151, 40);
		panel.add(btnInsert);
		
		JButton btnAtzera = new JButton("ATZERA");
		btnAtzera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				langilePantaila lanP = new langilePantaila();
				lanP.setVisible(true);
				dispose();
				
			}
		});
		btnAtzera.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnAtzera.setBounds(784, 38, 151, 40);
		panel.add(btnAtzera);
	}
	
public void insertLangilea() {
		
		String NAN = tfNAN.getText();
		String izena = tfIzena.getText();
		String abizena = tfAbizena.getText();
		String telefonoa = tfTelefonoa.getText();
		String helbidea = tfHelbidea.getText();
		String lanPostua = tfLanPostua.getText();
		String identifikadorea = tfIdentifikadorea.getText();
		String pasahitza = tfPasahitza.getText();
		
		if(NAN.isEmpty() || izena.isEmpty() || abizena.isEmpty() || telefonoa.isEmpty() || helbidea.isEmpty() || lanPostua.isEmpty() || 
				identifikadorea.isEmpty() || pasahitza.isEmpty()){
			
			JOptionPane.showMessageDialog(this, "Eremu guztiak bete behar dira!", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			return;
			
		}
		
		try {
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql = "insert into langilea (nan, izena, abizena, telefonoa, helbidea, lanPostua, identifikadorea, pasahitza) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, NAN);
			pst.setString(2, izena);
			pst.setString(3, abizena);
			pst.setString(4, telefonoa);
			pst.setString(5, helbidea);
			pst.setString(6, lanPostua);
			pst.setString(7, identifikadorea);
			pst.setString(8, pasahitza);
			pst.executeUpdate();
			
			JOptionPane.showMessageDialog(this, "Langilea ongi gehitu da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
			tfNAN.setText("");
			tfIzena.setText("");
			tfAbizena.setText("");
			tfTelefonoa.setText("");
			tfHelbidea.setText("");
			tfLanPostua.setText("");
			tfIdentifikadorea.setText("");
			tfPasahitza.setText("");

			
			
		} catch(Exception e) {
			
			JOptionPane.showMessageDialog(this, "Errorea " + e.getMessage() + " langilea sartzean: ", "Errorea", JOptionPane.ERROR_MESSAGE);
			
		}
		
	}
	
}
