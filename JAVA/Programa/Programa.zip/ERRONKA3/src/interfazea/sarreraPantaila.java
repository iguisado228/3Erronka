package interfazea;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import hornitzaileak.hornitzailea;
import hornitzaileak.hornitzaileaErakutsi;
import sarrera.sarrera;
import sarrera.sarreraErakutsi;

import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;

public class sarreraPantaila extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					sarreraPantaila frame = new sarreraPantaila();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}
	
private void sarreraKargatu() {
		
		sarreraErakutsi sarrerakErakutsi = new sarreraErakutsi();
		List <sarrera> sarrerak = sarrerakErakutsi.sarreraErakutsi();
		
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		model.setRowCount(0);
		
		for (sarrera sa : sarrerak) {
			
			model.addRow(new Object[] {sa.getIdSarrera(), sa.getIdLangilea(), sa.getIdEremua(), sa.getPrezioa()
				
			});
		}
}

	/**
	 * Create the frame.
	 */
	public sarreraPantaila() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 986, 563);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 61, 986, 502);
		panel.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"idSarrera", "idLangilea", "idEremua", "prezioa"
			}
		));
		scrollPane.setViewportView(table);
		sarreraKargatu();
		
		JButton btnSarreraHartu = new JButton("SARRERA HARTU");
		btnSarreraHartu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				sarreraAtera sarA = new sarreraAtera();
				sarA.setVisible(true);
				dispose();
				
			}
		});
		btnSarreraHartu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnSarreraHartu.setBounds(0, 0, 210, 62);
		panel.add(btnSarreraHartu);
		
		JButton btnAtzera = new JButton("ATZERA");
		btnAtzera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				menuOrokorra menO = new menuOrokorra();
				menO.setVisible(true);
				dispose();
				
			}	
		});
		btnAtzera.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnAtzera.setBounds(800, 0, 184, 62);
		panel.add(btnAtzera);
		
		JButton btnFakturaEgin = new JButton("FAKTURA EGIN");
		btnFakturaEgin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				sarrerenFaktura sarF = new sarrerenFaktura();
				sarF.setVisible(true);
				dispose();
				
			}
		});
		btnFakturaEgin.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnFakturaEgin.setBounds(220, 0, 210, 62);
		panel.add(btnFakturaEgin);
	}
}
