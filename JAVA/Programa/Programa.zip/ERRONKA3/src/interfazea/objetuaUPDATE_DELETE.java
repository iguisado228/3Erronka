package interfazea;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import konexioa.konexioa;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class objetuaUPDATE_DELETE extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfId;
	private JTextField tfIdHornitzailea;
	private JTextField tfIdEremua;
	private JTextField tfIzena;
	private JTextField tfData;
	private JTextField tfPrezioa;

	
	konexioa k = new konexioa();
	Connection conn = null; 
	ResultSet rs = null;
	PreparedStatement pst = null;
	
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					objetuaUPDATE_DELETE frame = new objetuaUPDATE_DELETE();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public objetuaUPDATE_DELETE() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 986, 563);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblTestua = new JLabel("Sartu editatu edo ezabatu nahi duzun ID-a");
		lblTestua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTestua.setBounds(40, 38, 394, 40);
		panel.add(lblTestua);
		
		tfId = new JTextField();
		tfId.setColumns(10);
		tfId.setBounds(450, 38, 151, 34);
		panel.add(tfId);
		
		tfIdHornitzailea = new JTextField();
		tfIdHornitzailea.setColumns(10);
		tfIdHornitzailea.setBounds(238, 125, 151, 34);
		panel.add(tfIdHornitzailea);
		
		tfIdEremua = new JTextField();
		tfIdEremua.setColumns(10);
		tfIdEremua.setBounds(238, 215, 151, 34);
		panel.add(tfIdEremua);
		
		tfIzena = new JTextField();
		tfIzena.setColumns(10);
		tfIzena.setBounds(238, 305, 151, 34);
		panel.add(tfIzena);
		
		tfData = new JTextField();
		tfData.setColumns(10);
		tfData.setBounds(752, 125, 151, 34);
		panel.add(tfData);
		
		tfPrezioa = new JTextField();
		tfPrezioa.setColumns(10);
		tfPrezioa.setBounds(752, 215, 151, 34);
		panel.add(tfPrezioa);
		
		JButton btnAtzera = new JButton("ATZERA");
		btnAtzera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				objetuPantaila objP = new objetuPantaila();
				objP.setVisible(true);
				dispose();
				
			}
		});
		btnAtzera.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnAtzera.setBounds(752, 485, 151, 40);
		panel.add(btnAtzera);
		
		JButton btnEzabatu = new JButton("EZABATU");
		btnEzabatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ezabatuMateriala();
				
			}
		});
		btnEzabatu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEzabatu.setBounds(623, 38, 151, 34);
		panel.add(btnEzabatu);
		
		JLabel lblIdHornitzailea = new JLabel("ID HORNITZAILEA");
		lblIdHornitzailea.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIdHornitzailea.setBounds(56, 125, 178, 40);
		panel.add(lblIdHornitzailea);
		
		JLabel lblId = new JLabel("ID EREMUA");
		lblId.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblId.setBounds(115, 215, 118, 40);
		panel.add(lblId);
		
		JLabel lblIzena = new JLabel("IZENA");
		lblIzena.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIzena.setBounds(115, 305, 66, 40);
		panel.add(lblIzena);
		
		JLabel lblData = new JLabel("DATA");
		lblData.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblData.setBounds(524, 125, 66, 40);
		panel.add(lblData);
		
		JLabel lblPrezioa = new JLabel("PREZIOA");
		lblPrezioa.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPrezioa.setBounds(524, 215, 118, 40);
		panel.add(lblPrezioa);
		
		JButton btnEditatu = new JButton("EDITATU");
		btnEditatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aldatuMateriala();
			}
		});
		btnEditatu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEditatu.setBounds(784, 38, 151, 34);
		panel.add(btnEditatu);
		
		JButton btnOsatu = new JButton("OSATU");
		btnOsatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				bilatuMateriala();
				
			}
		});
		btnOsatu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnOsatu.setBounds(592, 485, 151, 40);
		panel.add(btnOsatu);
	}
	
	public void aldatuMateriala() {
		String idMateriala = tfId.getText();
		String idHornitzailea = tfIdHornitzailea.getText();
		String idEremua = tfIdEremua.getText();
		String izena = tfIzena.getText();
		String data = tfData.getText();
		String prezioa = tfPrezioa.getText();
		

		

		if (idMateriala.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Ez duzu aukerarik aukeratu", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			
		}
		try {
			
			int ih = Integer.parseInt(idHornitzailea);
			int ie = Integer.parseInt(idEremua);
			int im = Integer.parseInt(idMateriala);
			double p = Double.parseDouble(prezioa);
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql="update materiala set idHornitzailea=?, idEremua=?, izena=?, data=?, prezioa=? where idMateriala=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, ih);
			pst.setInt(2, ie);
			pst.setString(3, izena);
			pst.setString(4, data);
			pst.setDouble(5, p);
			pst.setInt(6, im);
			pst.executeUpdate();
			
			
			tfIdHornitzailea.setText(idHornitzailea);
			tfIdEremua.setText(idEremua);
			tfIzena.setText(izena);
			tfData.setText(data);
			tfPrezioa.setText(prezioa);

		
	
			JOptionPane.showMessageDialog(this, "Materiala ongi aldatu da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
			tfId.setText("");
			
		}catch(Exception e)  {
			JOptionPane.showMessageDialog(this, "Materiala aldatzean errore bat egon da.", "Errorea", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void ezabatuMateriala() {
		String idMateriala = tfId.getText();

		if (idMateriala.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Ez duzu aukerarik aukeratu", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			
		}
		try {
			
			int im = Integer.parseInt(idMateriala);
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql="delete from materiala where idMateriala=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, im);
			pst.executeUpdate();

			
			JOptionPane.showMessageDialog(this, "Materiala ongi ezabatu da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
			tfId.setText("");
			
		}catch(Exception e)  {
			JOptionPane.showMessageDialog(this, "Materiala ezabatzean errore bat egon da.", "Errorea", JOptionPane.ERROR_MESSAGE);
		}
	}

	public void bilatuMateriala() {
	    String idMateriala = tfId.getText(); 

	    if (idMateriala.isEmpty()) {
	        JOptionPane.showMessageDialog(this, "Ez duzu ID bat sartu", "Errorea", JOptionPane.ERROR_MESSAGE);
	        return;
	    }

	    try {
	        int im = Integer.parseInt(idMateriala); 

	        Connection conn = konexioa.getConnection_(); 
	        String sql = "SELECT idHornitzailea, idEremua, izena, data, prezioa FROM materiala WHERE idMateriala=?"; 
	        PreparedStatement pst = conn.prepareStatement(sql);
	        pst.setInt(1, im);
	        ResultSet rs = pst.executeQuery(); 

	        if (rs.next()) { 
	        	
	        	tfIdHornitzailea.setText(rs.getString("idHornitzailea"));
	        	tfIdEremua.setText(rs.getString("idEremua"));
	        	tfIzena.setText(rs.getString("izena"));
	        	tfData.setText(rs.getString("data"));
	            tfPrezioa.setText(rs.getString("prezioa"));

	        } else {
	            JOptionPane.showMessageDialog(this, "Ez da materialik aurkitu ID honekin", "Abisua", JOptionPane.WARNING_MESSAGE);
	            tfIdHornitzailea.setText("");
	            tfIdEremua.setText("");
	            tfIzena.setText("");
	            tfData.setText("");
	            tfData.setText("");
	            tfPrezioa.setText("");
	           
	          
	        }


	    } catch (NumberFormatException e) {
	        JOptionPane.showMessageDialog(this, "ID-a zenbaki bat izan behar da", "Errorea", JOptionPane.ERROR_MESSAGE);
	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this, "Errore bat gertatu da bilaketa egiterakoan", "Errorea", JOptionPane.ERROR_MESSAGE);
	    }
	}
	
}
