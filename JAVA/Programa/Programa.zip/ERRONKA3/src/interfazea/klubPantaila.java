package interfazea;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import bazkideak.bazkidea;
import bazkideak.bazkideaErakutsi;
import kluba.kluba;
import kluba.klubaErakutsi;

public class klubPantaila extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					klubPantaila frame = new klubPantaila();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}
	
private void klubaKargatu() {
		
		klubaErakutsi klubakErakutsi = new klubaErakutsi();
		List <kluba> klubak = klubakErakutsi.klubaErakutsi();
		
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		model.setRowCount(0);
		
		for (kluba kl : klubak) {
			
			model.addRow(new Object[] {kl.getIdKluba(), kl.getIdentifikadorea(), kl.getPasahitza(), kl.getIzena(), kl.getKirola(), kl.getJokalariKopurua(), 
					kl.getTaldeKopurua()
			});
		}
}

	/**
	 * Create the frame.
	 */
	public klubPantaila() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 986, 563);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton btnInsert = new JButton("INSERT");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				klubaInsert klubI = new klubaInsert();
				klubI.setVisible(true);
				dispose();
				
			}
		});
		btnInsert.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnInsert.setBounds(0, 0, 184, 62);
		panel.add(btnInsert);
		
		JButton btnUpdatedelete = new JButton("UPDATE/DELETE");
		btnUpdatedelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				klubUPDATE_DELETE klubUD = new klubUPDATE_DELETE();
				klubUD.setVisible(true);
				dispose();
				
			}
		});
		btnUpdatedelete.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnUpdatedelete.setBounds(191, 0, 184, 62);
		panel.add(btnUpdatedelete);
		
		JButton btnAtzera = new JButton("ATZERA");
		btnAtzera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				menuOrokorra menO = new menuOrokorra();
				menO.setVisible(true);
				dispose();
				
			}
		});
		btnAtzera.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnAtzera.setBounds(800, 0, 184, 62);
		panel.add(btnAtzera);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 61, 986, 504);
		panel.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null}
			},
			new String[] {
				"idKluba", "identifikadorea", "pasahitza", "izena", "kirola", "jokalariKopurua", "taldeKopurua"
			}
		));
		scrollPane.setViewportView(table);
		klubaKargatu();
	}
}
