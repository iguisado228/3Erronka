package interfazea;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import konexioa.konexioa;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class taldeaInsert extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfIdKluba;
	private JTextField tfKategoria;
	private JTextField tfJokalariKopurua;
	
	konexioa k = new konexioa();
	Connection conn = null; 
	ResultSet rs = null;
	PreparedStatement pst = null;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					taldeaInsert frame = new taldeaInsert();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public taldeaInsert() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 986, 563);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblOndorengoEremuakBete = new JLabel("Ondorengo eremuak bete talde berriaren datuak sartzeko");
		lblOndorengoEremuakBete.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblOndorengoEremuakBete.setBounds(43, 38, 563, 40);
		panel.add(lblOndorengoEremuakBete);
		
		JButton btnInsert = new JButton("INSERT");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				insertTaldea();
				
			}
		});
		btnInsert.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnInsert.setBounds(623, 38, 151, 40);
		panel.add(btnInsert);
		
		JButton btnAtzera = new JButton("ATZERA");
		btnAtzera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				taldeaPantaila talP = new taldeaPantaila();
				talP.setVisible(true);
				dispose();
				
			}
		});
		btnAtzera.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnAtzera.setBounds(784, 38, 151, 40);
		panel.add(btnAtzera);
		
		JLabel lblIdKluba = new JLabel("ID KLUBA");
		lblIdKluba.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIdKluba.setBounds(115, 125, 178, 40);
		panel.add(lblIdKluba);
		
		JLabel lblJokalariKopurua = new JLabel("JOKALARI KOPURUA");
		lblJokalariKopurua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblJokalariKopurua.setBounds(524, 125, 218, 40);
		panel.add(lblJokalariKopurua);
		
		JLabel lblKategoria = new JLabel("KATEGORIA");
		lblKategoria.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblKategoria.setBounds(115, 305, 178, 40);
		panel.add(lblKategoria);
		
		tfIdKluba = new JTextField();
		tfIdKluba.setColumns(10);
		tfIdKluba.setBounds(238, 125, 151, 34);
		panel.add(tfIdKluba);
		
		tfKategoria = new JTextField();
		tfKategoria.setColumns(10);
		tfKategoria.setBounds(238, 305, 151, 34);
		panel.add(tfKategoria);
		
		tfJokalariKopurua = new JTextField();
		tfJokalariKopurua.setColumns(10);
		tfJokalariKopurua.setBounds(752, 125, 151, 34);
		panel.add(tfJokalariKopurua);
	}
	
public void insertTaldea() {
		
		String idKluba = tfIdKluba.getText();
		String kategoria = tfKategoria.getText();
		String jokalariKopurua = tfJokalariKopurua.getText();
		
		
		if(idKluba.isEmpty() || kategoria.isEmpty() || jokalariKopurua.isEmpty()) {
			
			JOptionPane.showMessageDialog(this, "Eremu guztiak bete behar dira!", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			return;
			
		}
		
		try {
			
			int ik = Integer.parseInt(idKluba);
			int jk = Integer.parseInt(jokalariKopurua);
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql = "insert into taldea (idKluba, kategoria, jokalariKopurua) VALUES (?, ?, ?)";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, ik);
			pst.setString(2, kategoria);
			pst.setInt(3, jk);
			pst.executeUpdate();
			
			JOptionPane.showMessageDialog(this, "Taldea ongi gehitu da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
			tfIdKluba.setText("");
			tfKategoria.setText("");
			tfJokalariKopurua.setText("");

			
			
		} catch(Exception e) {
			
			JOptionPane.showMessageDialog(this, "Errorea " + e.getMessage() + " taldea sartzean: ", "Errorea", JOptionPane.ERROR_MESSAGE);
			
		}
		
	}
	
}
