package interfazea;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import konexioa.konexioa;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class taldeUPDATE_DELETE extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfIdKluba;
	private JTextField tfKategoria;
	private JTextField tfJokalariKopurua;
	private JTextField tfId;


	konexioa k = new konexioa();
	Connection conn = null; 
	ResultSet rs = null;
	PreparedStatement pst = null;
	
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					taldeUPDATE_DELETE frame = new taldeUPDATE_DELETE();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public taldeUPDATE_DELETE() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 986, 563);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblTestua = new JLabel("Sartu editatu edo ezabatu nahi duzun ID-a");
		lblTestua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTestua.setBounds(40, 38, 394, 40);
		panel.add(lblTestua);
		
		tfIdKluba = new JTextField();
		tfIdKluba.setColumns(10);
		tfIdKluba.setBounds(238, 125, 151, 34);
		panel.add(tfIdKluba);
		
		tfKategoria = new JTextField();
		tfKategoria.setColumns(10);
		tfKategoria.setBounds(238, 305, 151, 34);
		panel.add(tfKategoria);
		
		tfJokalariKopurua = new JTextField();
		tfJokalariKopurua.setColumns(10);
		tfJokalariKopurua.setBounds(752, 125, 151, 34);
		panel.add(tfJokalariKopurua);
		
		JButton btnEzabatu = new JButton("EZABATU");
		btnEzabatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ezabatuTaldea();
				
			}
		});
		btnEzabatu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEzabatu.setBounds(623, 38, 151, 34);
		panel.add(btnEzabatu);
		
		JButton btnEditatu = new JButton("EDITATU");
		btnEditatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				aldatuTaldea();
				
			}
		});
		btnEditatu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEditatu.setBounds(784, 38, 151, 34);
		panel.add(btnEditatu);
		
		tfId = new JTextField();
		tfId.setColumns(10);
		tfId.setBounds(450, 38, 151, 34);
		panel.add(tfId);
		
		JLabel lblIdKluba = new JLabel("ID KLUBA");
		lblIdKluba.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIdKluba.setBounds(115, 125, 178, 40);
		panel.add(lblIdKluba);
		
		JLabel lblKategoria = new JLabel("KATEGORIA");
		lblKategoria.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblKategoria.setBounds(115, 305, 178, 40);
		panel.add(lblKategoria);
		
		JLabel lblJokalariKopurua = new JLabel("JOKALARI KOPURUA");
		lblJokalariKopurua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblJokalariKopurua.setBounds(524, 125, 218, 40);
		panel.add(lblJokalariKopurua);
		
		JButton btnAtzera = new JButton("ATZERA");
		btnAtzera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				taldeaPantaila talP = new taldeaPantaila();
				talP.setVisible(true);
				dispose();
				
			}
		});
		btnAtzera.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnAtzera.setBounds(752, 484, 151, 40);
		panel.add(btnAtzera);
		
		JButton btnOsatu = new JButton("OSATU");
		btnOsatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				bilatuTaldea();
				
			}
		});
		btnOsatu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnOsatu.setBounds(592, 484, 151, 40);
		panel.add(btnOsatu);
	}

	public void aldatuTaldea() {
		String idTaldea = tfId.getText();
		String idKluba = tfIdKluba.getText();
		String kategoria = tfKategoria.getText();
		String jokalariKopurua = tfJokalariKopurua.getText();

		

		

		if (idTaldea.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Ez duzu aukerarik aukeratu", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			
		}
		try {
			
			int ik = Integer.parseInt(idKluba);
			int jk = Integer.parseInt(jokalariKopurua);
			int it = Integer.parseInt(idTaldea);
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql="update taldea set idKluba=?, kategoria=?, jokalariKopurua=? where idTaldea=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, ik);
			pst.setString(2, kategoria);
			pst.setInt(3, jk);
			pst.setInt(4, it);
			pst.executeUpdate();
			
			
			tfIdKluba.setText(idKluba);
			tfKategoria.setText(kategoria);
			tfJokalariKopurua.setText(jokalariKopurua);
			

		
	
			JOptionPane.showMessageDialog(this, "Taldea ongi aldatu da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
			tfId.setText("");
			
		}catch(Exception e)  {
			JOptionPane.showMessageDialog(this, "taldea aldatzean errore bat egon da.", "Errorea", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void ezabatuTaldea() {
		String idTaldea = tfId.getText();

		if (idTaldea.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Ez duzu aukerarik aukeratu", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			
		}
		try {
			
			int it = Integer.parseInt(idTaldea);
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql="delete from taldea where idTaldea=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, it);
			pst.executeUpdate();

			
			JOptionPane.showMessageDialog(this, "Taldea ongi ezabatu da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
			tfId.setText("");
			
		}catch(Exception e)  {
			JOptionPane.showMessageDialog(this, "Taldea ezabatzean errore bat egon da.", "Errorea", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void bilatuTaldea() {
	    String idTaldea = tfId.getText(); 

	    if (idTaldea.isEmpty()) {
	        JOptionPane.showMessageDialog(this, "Ez duzu ID bat sartu", "Errorea", JOptionPane.ERROR_MESSAGE);
	        return;
	    }

	    try {
	        int it = Integer.parseInt(idTaldea); 

	        Connection conn = konexioa.getConnection_(); 
	        String sql = "SELECT idKluba, kategoria, jokalariKopurua FROM taldea WHERE idTaldea=?"; 
	        PreparedStatement pst = conn.prepareStatement(sql);
	        pst.setInt(1, it);
	        ResultSet rs = pst.executeQuery(); 

	        if (rs.next()) { 
	        	
	        	tfIdKluba.setText(rs.getString("idKluba"));
	        	tfKategoria.setText(rs.getString("kategoria"));
	        	tfJokalariKopurua.setText(rs.getString("jokalariKopurua"));

	        } else {
	            JOptionPane.showMessageDialog(this, "Ez da talderik aurkitu ID honekin", "Abisua", JOptionPane.WARNING_MESSAGE);
	            tfIdKluba.setText("");
	            tfKategoria.setText("");
	            tfJokalariKopurua.setText("");
	           
	          
	        }


	    } catch (NumberFormatException e) {
	        JOptionPane.showMessageDialog(this, "ID-a zenbaki bat izan behar da", "Errorea", JOptionPane.ERROR_MESSAGE);
	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this, "Errore bat gertatu da bilaketa egiterakoan", "Errorea", JOptionPane.ERROR_MESSAGE);
	    }
	}
	
}
