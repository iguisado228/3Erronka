	
package interfazea;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bazkideak.bazkidea;
import konexioa.konexioa;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class bazkideUPDATE_DELETE extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfId;
	private JTextField tfNAN;
	private JTextField tfIzena;
	private JTextField tfAbizena;
	private JTextField tfTelefonoa;
	private JLabel lblHelbidea;
	private JLabel lblIdentifikadorea;
	private JLabel lblPasahitza;
	private JTextField tfHelbidea;
	private JTextField tfIdentifikadorea;
	private JTextField tfPasahitza;
	private JButton btnEzabatu;
	private JButton btnEditatu;
	private JButton btnAtzera;
	
	
	konexioa k = new konexioa();
	Connection conn = null; 
	ResultSet rs = null;
	PreparedStatement pst = null;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					bazkideUPDATE_DELETE frame = new bazkideUPDATE_DELETE();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public bazkideUPDATE_DELETE() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 986, 563);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblTestua = new JLabel("Sartu editatu edo ezabatu nahi duzun ID-a");
		lblTestua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTestua.setBounds(40, 38, 394, 40);
		panel.add(lblTestua);
		
		tfId = new JTextField();
		tfId.setBounds(450, 36, 151, 34);
		panel.add(tfId);
		tfId.setColumns(10);
		
		JLabel lblNAN = new JLabel("NAN");
		lblNAN.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNAN.setBounds(375, 127, 45, 40);
		panel.add(lblNAN);
		
		JLabel lblIzena = new JLabel("IZENA");
		lblIzena.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIzena.setBounds(115, 215, 61, 40);
		panel.add(lblIzena);
		
		JLabel lblAbizena = new JLabel("ABIZENA");
		lblAbizena.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblAbizena.setBounds(115, 305, 99, 40);
		panel.add(lblAbizena);
		
		tfNAN = new JTextField();
		tfNAN.setColumns(10);
		tfNAN.setBounds(450, 127, 151, 34);
		panel.add(tfNAN);
		
		tfIzena = new JTextField();
		tfIzena.setColumns(10);
		tfIzena.setBounds(238, 215, 151, 34);
		panel.add(tfIzena);
		
		tfAbizena = new JTextField();
		tfAbizena.setColumns(10);
		tfAbizena.setBounds(238, 305, 151, 34);
		panel.add(tfAbizena);
		
		JLabel lblTelefonoa = new JLabel("TELEFONOA");
		lblTelefonoa.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTelefonoa.setBounds(115, 400, 129, 40);
		panel.add(lblTelefonoa);
		
		tfTelefonoa = new JTextField();
		tfTelefonoa.setColumns(10);
		tfTelefonoa.setBounds(238, 400, 151, 34);
		panel.add(tfTelefonoa);
		
		lblHelbidea = new JLabel("HELBIDEA");
		lblHelbidea.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblHelbidea.setBounds(524, 215, 129, 40);
		panel.add(lblHelbidea);
		
		lblIdentifikadorea = new JLabel("IDENTIFIKADOREA");
		lblIdentifikadorea.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIdentifikadorea.setBounds(524, 305, 177, 40);
		panel.add(lblIdentifikadorea);
		
		lblPasahitza = new JLabel("PASAHITZA");
		lblPasahitza.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPasahitza.setBounds(524, 400, 129, 40);
		panel.add(lblPasahitza);
		
		tfHelbidea = new JTextField();
		tfHelbidea.setColumns(10);
		tfHelbidea.setBounds(752, 215, 151, 34);
		panel.add(tfHelbidea);
		
		tfIdentifikadorea = new JTextField();
		tfIdentifikadorea.setColumns(10);
		tfIdentifikadorea.setBounds(752, 305, 151, 34);
		panel.add(tfIdentifikadorea);
		
		tfPasahitza = new JTextField();
		tfPasahitza.setColumns(10);
		tfPasahitza.setBounds(752, 400, 151, 34);
		panel.add(tfPasahitza);
		
		btnEzabatu = new JButton("EZABATU");
		btnEzabatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ezabatuBazkidea();
				
			}
		});
		btnEzabatu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEzabatu.setBounds(623, 38, 151, 34);
		panel.add(btnEzabatu);
		
		btnEditatu = new JButton("EDITATU");
		btnEditatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aldatuBazkidea();
			}
		});
		btnEditatu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEditatu.setBounds(784, 38, 151, 34);
		panel.add(btnEditatu);
		
		btnAtzera = new JButton("ATZERA");
		btnAtzera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				bazkidePantaila bazP = new bazkidePantaila();
				bazP.setVisible(true);
				dispose();
				
			}
		});
		btnAtzera.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnAtzera.setBounds(752, 485, 151, 40);
		panel.add(btnAtzera);
		
		JButton btnOsatu = new JButton("OSATU");
		btnOsatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				bilatuBazkidea();
				
			}
		});
		btnOsatu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnOsatu.setBounds(592, 485, 151, 40);
		panel.add(btnOsatu);
	}
	
	
	public void aldatuBazkidea() {
		String idBazkidea = tfId.getText();
		String NAN = tfNAN.getText();
		String izena = tfIzena.getText();
		String abizena = tfAbizena.getText();
		String telefonoa = tfTelefonoa.getText();
		String helbidea = tfHelbidea.getText();
		String identifikadorea = tfIdentifikadorea.getText();
		String pasahitza = tfPasahitza.getText();

		if (idBazkidea.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Ez duzu aukerarik aukeratu", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			
		}
		try {
			
			int ib = Integer.parseInt(idBazkidea);
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql="update bazkidea set nan=?, izena=?, abizena=?, telefonoa=?, helbidea=?, identifikadorea=?, pasahitza=? where idBazkidea=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, NAN);
			pst.setString(2, izena);
			pst.setString(3,  abizena);
			pst.setString(4, telefonoa);
			pst.setString(5,  helbidea);
			pst.setString(6, identifikadorea);
			pst.setString(7, pasahitza);
			pst.setInt(8, ib);
			pst.executeUpdate();
			
			tfNAN.setText(NAN);
			tfIzena.setText(izena);
			tfAbizena.setText(abizena);
			tfTelefonoa.setText(telefonoa);
			tfHelbidea.setText(helbidea);
			tfIdentifikadorea.setText(identifikadorea);
			tfPasahitza.setText(pasahitza);
			
			JOptionPane.showMessageDialog(this, "Bazkidea ongi aldatu da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
			tfId.setText("");
			
		}catch(Exception e)  {
			JOptionPane.showMessageDialog(this, "Bazkidea aldatzean errore bat egon da.", "Errorea", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void ezabatuBazkidea() {
		String idBazkidea = tfId.getText();

		if (idBazkidea.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Ez duzu aukerarik aukeratu", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			
		}
		try {
			
			int ib = Integer.parseInt(idBazkidea);
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql="delete from bazkidea where idBazkidea=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, ib);
			pst.executeUpdate();

			
			JOptionPane.showMessageDialog(this, "Bazkidea ongi ezabatu da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
			tfId.setText("");
			
		}catch(Exception e)  {
			JOptionPane.showMessageDialog(this, "Bazkidea ezabatzean errore bat egon da.", "Errorea", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	
	
	public void bilatuBazkidea() {
	    String idBazkidea = tfId.getText(); 

	    if (idBazkidea.isEmpty()) {
	        JOptionPane.showMessageDialog(this, "Ez duzu ID bat sartu", "Errorea", JOptionPane.ERROR_MESSAGE);
	        return;
	    }

	    try {
	        int ib = Integer.parseInt(idBazkidea);

	        Connection conn = konexioa.getConnection_();
	        String sql = "SELECT NAN, izena, abizena, telefonoa, helbidea, identifikadorea, pasahitza FROM bazkidea WHERE idBazkidea=?"; // Consulta SQL
	        PreparedStatement pst = conn.prepareStatement(sql);
	        pst.setInt(1, ib);
	        ResultSet rs = pst.executeQuery(); 

	        if (rs.next()) { 
	            tfIzena.setText(rs.getString("izena"));
	            tfAbizena.setText(rs.getString("abizena"));
	            tfTelefonoa.setText(rs.getString("telefonoa"));
	            tfNAN.setText(rs.getString("NAN"));
	            tfHelbidea.setText(rs.getString("helbidea"));
	            tfIdentifikadorea.setText(rs.getString("identifikadorea"));
	            tfPasahitza.setText(rs.getString("pasahitza"));
	        } else {
	            JOptionPane.showMessageDialog(this, "Ez da bazkiderik aurkitu ID honekin", "Abisua", JOptionPane.WARNING_MESSAGE);
	            tfIzena.setText("");
	            tfAbizena.setText("");
	            tfTelefonoa.setText("");
	            tfNAN.setText("");
	            tfHelbidea.setText("");
	            tfIdentifikadorea.setText("");
	            tfPasahitza.setText("");
	        }


	    } catch (NumberFormatException e) {
	        JOptionPane.showMessageDialog(this, "ID-a zenbaki bat izan behar da", "Errorea", JOptionPane.ERROR_MESSAGE);
	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this, "Errore bat gertatu da bilaketa egiterakoan", "Errorea", JOptionPane.ERROR_MESSAGE);
	    }
	}
}

