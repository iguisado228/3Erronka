package interfazea;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import konexioa.konexioa;
import sarrera.sarrera;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;

import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.common.PDRectangle;



public class sarrerenFaktura extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfId;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					sarrerenFaktura frame = new sarrerenFaktura();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public sarrerenFaktura() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 986, 563);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblSarreraBerriarenIda = new JLabel("Sarrera berriaren id-a sartu faktura ateratzeko");
		lblSarreraBerriarenIda.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblSarreraBerriarenIda.setBounds(100, 250, 425, 40);
		panel.add(lblSarreraBerriarenIda);
		
		JButton btnFaktura = new JButton("FAKTURA");
		btnFaktura.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				pdfSortu();
				
			}
		});
		btnFaktura.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnFaktura.setBounds(700, 250, 151, 40);
		panel.add(btnFaktura);
		
		tfId = new JTextField();
		tfId.setText("");
		tfId.setBounds(530, 250, 151, 40);
		panel.add(tfId);
		
		JButton btnAtzera = new JButton("ATZERA");
		btnAtzera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				sarreraPantaila sarP = new sarreraPantaila();
				sarP.setVisible(true);
				dispose();
				
			}
		});
		btnAtzera.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnAtzera.setBounds(825, 10, 151, 40);
		panel.add(btnAtzera);
	}
	
	public void pdfSortu() {
		
		String idSarrera = tfId.getText();
		
		if (idSarrera.isEmpty()) {
			
			JOptionPane.showMessageDialog(this, "Ez duzu bezerorik aukeratu", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			return;
		} else {
			
			List <sarrera> sarrerak = new ArrayList<>();
			Connection conn = null;
			ResultSet rs = null;
			PreparedStatement pst = null;
			
			
			
			//konexioa k = new konexioa();
			try {
				conn = konexioa.getConnection_();
				
				String sql = "select * from sarrera where idSarrera = ?";
				pst = conn.prepareStatement(sql);
				int is = Integer.parseInt(idSarrera);
				pst.setInt(1, is);
				rs = pst.executeQuery();
				
				while (rs.next()) {
					
					sarrera sa = new sarrera (rs.getInt("idSarrera"), rs.getInt("idLangilea"), rs.getInt("idEremua"), rs.getDouble("prezioa"));
					
					sarrerak.add(sa);
					
				}
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			if (sarrerak.isEmpty()) {
				
				JOptionPane.showMessageDialog(this, "Ez da aurkitu eskaerarik ID horrekin", "Errorea",  JOptionPane.ERROR_MESSAGE);
				return;
				
			}
			
			for (sarrera sa : sarrerak) {
				
				try {
					
					//DOKUMENTU BERRI BAT SORTZEN DUGU
					PDDocument dokumentua = new PDDocument();
					
					//ORRI BERRI BAT SORTZEN DUGU
					PDPage orria = new PDPage(PDRectangle.A4);
					dokumentua.addPage(orria);
					
					//PDF-an logoa sartzeko imagena sortzen degu
					String imgSrc = "irudiak\\allurraldeLogo.jpg";
					PDImageXObject image1 = PDImageXObject.createFromFile(imgSrc, dokumentua);
					
					
					
					//PDFaren kontenidoa zein izango den esaten diogu
					PDPageContentStream edukia = new PDPageContentStream(dokumentua, orria);
					
					edukia.drawImage(image1, 450, 700, 100, 100);
					edukia.setLeading(20f);
					
					//EDUKIA ALDATU BEHAR DUGUN BAKOITZENA EGIN BEHAR DUGU
					//KASU HONETAN IZENBURUA JARTZEN DUGU
					edukia.beginText();
					edukia.setFont(PDType1Font.COURIER_BOLD, 42);
					edukia.newLineAtOffset(20, orria.getMediaBox().getHeight()-(52));
					edukia.showText("FAKTURA "+sa.getIdSarrera());
					edukia.endText();
					
					edukia.beginText();
					edukia.setFont(PDType1Font.HELVETICA, 16);
					edukia.newLineAtOffset(20, orria.getMediaBox().getHeight() - 100);
					edukia.showText("Langilearen ID-a: " + sa.getIdLangilea()); 	
					edukia.newLine();
					edukia.newLine();
					edukia.showText("Eremuaren ID-a: " + sa.getIdEremua());
					edukia.newLine();
					edukia.newLine();
					edukia.showText("Prezioa: " + sa.getPrezioa()+ "€");
					edukia.newLine();
					edukia.newLine();
					edukia.newLine();
					edukia.newLine();
					edukia.newLine();
					edukia.newLine();
					edukia.newLine();
					edukia.newLine();
					edukia.showText("Eskerrik asko gure zerbitzuak erabiltzeagatik!");
					edukia.endText();
					
					
					//EDUKIA ALDATZEN BUKATUTAKOAN ITXI EGITEN DUGU
					edukia.close();
					
					//DOKUMENTUA GORDETZEN DUGU
					dokumentua.save(sa.getIdSarrera()+ "_Faktura"+".pdf");
					dokumentua.close();
					JOptionPane.showMessageDialog(contentPane, "Faktura sortu da", "Faktura", JOptionPane.INFORMATION_MESSAGE);
					
					
					
				}catch(Exception e) {
					
					e.printStackTrace();
					JOptionPane.showMessageDialog(contentPane, "Gaizki joan da", "Error", JOptionPane.ERROR_MESSAGE);
					
				}
				
			}
			
		}
		
	}
	
}
