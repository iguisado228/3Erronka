package interfazea;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import konexioa.konexioa;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import java.awt.event.ActionEvent;

public class mantenuaInsert extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfIdLangilea;
	private JTextField tfIdEremua;
	private JTextField tfMota;
	private JTextField tfData;
	private JTextField tfEgoera;
	private JTextField tfBeharrekoa;
	
	konexioa k = new konexioa();
	Connection conn = null; 
	ResultSet rs = null;
	PreparedStatement pst = null;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					mantenuaInsert frame = new mantenuaInsert();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public mantenuaInsert() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 986, 563);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblOndorengoEremuakBete = new JLabel("Ondorengo eremuak bete mantenuaren datu berriak sartzeko");
		lblOndorengoEremuakBete.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblOndorengoEremuakBete.setBounds(43, 38, 563, 40);
		panel.add(lblOndorengoEremuakBete);
		
		JButton btnInsert = new JButton("INSERT");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				insertMantenua();
				
			}
		});
		btnInsert.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnInsert.setBounds(623, 38, 151, 40);
		panel.add(btnInsert);
		
		JButton btnAtzera = new JButton("ATZERA");
		btnAtzera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				mantenuaPantaila manP = new mantenuaPantaila();
				manP.setVisible(true);
				dispose();
				
			}
		});
		btnAtzera.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnAtzera.setBounds(784, 38, 151, 40);
		panel.add(btnAtzera);
		
		JLabel lblIdLangilea = new JLabel("ID LANGILEA");
		lblIdLangilea.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIdLangilea.setBounds(115, 125, 178, 40);
		panel.add(lblIdLangilea);
		
		JLabel lblIdEremua = new JLabel("ID EREMUA");
		lblIdEremua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIdEremua.setBounds(115, 215, 178, 40);
		panel.add(lblIdEremua);
		
		JLabel lblMota = new JLabel("MOTA");
		lblMota.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblMota.setBounds(115, 305, 178, 40);
		panel.add(lblMota);
		
		JLabel lblData = new JLabel("DATA");
		lblData.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblData.setBounds(524, 125, 178, 40);
		panel.add(lblData);
		
		JLabel lblEgoera = new JLabel("EGOERA");
		lblEgoera.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblEgoera.setBounds(524, 215, 178, 40);
		panel.add(lblEgoera);
		
		JLabel lblBeharrekoa = new JLabel("BEHARREKOA");
		lblBeharrekoa.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblBeharrekoa.setBounds(524, 305, 178, 40);
		panel.add(lblBeharrekoa);
		
		tfIdLangilea = new JTextField();
		tfIdLangilea.setColumns(10);
		tfIdLangilea.setBounds(238, 125, 151, 34);
		panel.add(tfIdLangilea);
		
		tfIdEremua = new JTextField();
		tfIdEremua.setColumns(10);
		tfIdEremua.setBounds(238, 215, 151, 34);
		panel.add(tfIdEremua);
		
		tfMota = new JTextField();
		tfMota.setColumns(10);
		tfMota.setBounds(238, 305, 151, 34);
		panel.add(tfMota);
		
		tfData = new JTextField();
		tfData.setColumns(10);
		tfData.setBounds(752, 125, 151, 34);
		panel.add(tfData);
		
		tfEgoera = new JTextField();
		tfEgoera.setColumns(10);
		tfEgoera.setBounds(752, 215, 151, 34);
		panel.add(tfEgoera);
		
		tfBeharrekoa = new JTextField();
		tfBeharrekoa.setColumns(10);
		tfBeharrekoa.setBounds(752, 305, 151, 34);
		panel.add(tfBeharrekoa);
	}
	
public void insertMantenua() {
		
		String idLangilea = tfIdLangilea.getText();
		String idEremua = tfIdEremua.getText();
		String mota = tfMota.getText();
		String data = tfData.getText();
		String egoera = tfEgoera.getText();
		String beharrekoa = tfBeharrekoa.getText();
		
		if(idLangilea.isEmpty() || idEremua.isEmpty() || mota.isEmpty() || data.isEmpty() || egoera.isEmpty() || beharrekoa.isEmpty()) {
			
			JOptionPane.showMessageDialog(this, "Eremu guztiak bete behar dira!", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			return;
			
		}
		
		try {
			
			int il = Integer.parseInt(idLangilea);
			int ie = Integer.parseInt(idEremua);
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql = "insert into mantenua (idLangilea, idEremua, mota, data, egoera, beharrekoa) VALUES (?, ?, ?, ?, ?, ?)";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, il);
			pst.setInt(2, ie);
			pst.setString(3, mota);
			pst.setString(4, data);
			pst.setString(5, egoera);
			pst.setString(6, beharrekoa);
			pst.executeUpdate();
			
			JOptionPane.showMessageDialog(this, "Mantenua ongi gehitu da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
			tfIdLangilea.setText("");
			tfIdEremua.setText("");
			tfMota.setText("");
			tfData.setText("");
			tfEgoera.setText("");
			tfBeharrekoa.setText("");

			
			
		} catch(Exception e) {
			
			JOptionPane.showMessageDialog(this, "Errorea " + e.getMessage() + " mantenua sartzean: ", "Errorea", JOptionPane.ERROR_MESSAGE);
			
		}
		
	}
	
}
