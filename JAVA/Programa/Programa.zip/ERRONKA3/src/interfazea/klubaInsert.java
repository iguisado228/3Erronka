package interfazea;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import konexioa.konexioa;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class klubaInsert extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfIdentifikadorea;
	private JTextField tfKirola;
	private JTextField tfPasahitza;
	private JTextField tfIzena;
	private JTextField tfJokalariKopurua;
	private JTextField tfTaldeKopurua;
	
	konexioa k = new konexioa();
	Connection conn = null; 
	ResultSet rs = null;
	PreparedStatement pst = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					klubaInsert frame = new klubaInsert();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public klubaInsert() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 986, 563);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblTestua = new JLabel("Ondorengo eremuak bete klub berriaren datuak sartzeko");
		lblTestua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTestua.setBounds(43, 38, 546, 25);
		panel.add(lblTestua);
		
		JButton btnInsert = new JButton("INSERT");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				insertKluba();
				
			}
		});
		btnInsert.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnInsert.setBounds(623, 38, 151, 40);
		panel.add(btnInsert);
		
		JLabel lblIdentifikadorea = new JLabel("IDENTIFIKADOREA");
		lblIdentifikadorea.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIdentifikadorea.setBounds(61, 125, 191, 34);
		panel.add(lblIdentifikadorea);
		
		JLabel lblPasahitza = new JLabel("PASAHITZA");
		lblPasahitza.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPasahitza.setBounds(115, 215, 113, 34);
		panel.add(lblPasahitza);
		
		JLabel lblIzena = new JLabel("IZENA");
		lblIzena.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIzena.setBounds(115, 305, 70, 34);
		panel.add(lblIzena);
		
		JLabel lblKirola = new JLabel("KIROLA");
		lblKirola.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblKirola.setBounds(524, 125, 70, 34);
		panel.add(lblKirola);
		
		JLabel lblJokalariKopurua = new JLabel("JOKALARI KOPURUA");
		lblJokalariKopurua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblJokalariKopurua.setBounds(524, 215, 191, 34);
		panel.add(lblJokalariKopurua);
		
		JLabel lblTaldeKopurua = new JLabel("TALDE KOPURUA");
		lblTaldeKopurua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTaldeKopurua.setBounds(524, 305, 165, 34);
		panel.add(lblTaldeKopurua);
		
		tfIdentifikadorea = new JTextField();
		tfIdentifikadorea.setColumns(10);
		tfIdentifikadorea.setBounds(238, 125, 151, 34);
		panel.add(tfIdentifikadorea);
		
		tfKirola = new JTextField();
		tfKirola.setColumns(10);
		tfKirola.setBounds(752, 125, 151, 34);
		panel.add(tfKirola);
		
		tfPasahitza = new JTextField();
		tfPasahitza.setColumns(10);
		tfPasahitza.setBounds(238, 215, 151, 34);
		panel.add(tfPasahitza);
		
		tfIzena = new JTextField();
		tfIzena.setColumns(10);
		tfIzena.setBounds(238, 305, 151, 34);
		panel.add(tfIzena);
		
		tfJokalariKopurua = new JTextField();
		tfJokalariKopurua.setColumns(10);
		tfJokalariKopurua.setBounds(752, 215, 151, 34);
		panel.add(tfJokalariKopurua);
		
		tfTaldeKopurua = new JTextField();
		tfTaldeKopurua.setColumns(10);
		tfTaldeKopurua.setBounds(752, 305, 151, 34);
		panel.add(tfTaldeKopurua);
		
		JButton btnAtzera = new JButton("ATZERA");
		btnAtzera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				klubPantaila klubP = new klubPantaila();
				klubP.setVisible(true);
				dispose();
				
			}
		});
		btnAtzera.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnAtzera.setBounds(784, 38, 151, 40);
		panel.add(btnAtzera);
	}
	
public void insertKluba() {
		
		String identifikadorea = tfIdentifikadorea.getText();
		String pasahitza = tfPasahitza.getText();
		String izena = tfIzena.getText();
		String kirola = tfKirola.getText();
		String jokalariKopurua = tfJokalariKopurua.getText();
		String taldeKopurua = tfTaldeKopurua.getText();
		
		if(identifikadorea.isEmpty() || pasahitza.isEmpty() || izena.isEmpty() || kirola.isEmpty() || jokalariKopurua.isEmpty() || taldeKopurua.isEmpty()){
			
			JOptionPane.showMessageDialog(this, "Eremu guztiak bete behar dira!", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			return;
			
		}
		
		try {
			
			int jk = Integer.parseInt(jokalariKopurua);
			int tk = Integer.parseInt(taldeKopurua);
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql = "insert into kluba (identifikadorea, pasahitza, izena, kirola, jokalariKopurua, taldeKopurua) VALUES (?, ?, ?, ?, ?, ?)";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, identifikadorea);
			pst.setString(2, pasahitza);
			pst.setString(3, izena);
			pst.setString(4, kirola);
			pst.setInt(5, jk);
			pst.setInt(6, tk);
			pst.executeUpdate();
			
			JOptionPane.showMessageDialog(this, "Kluba ongi gehitu da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
			tfIdentifikadorea.setText("");
			tfPasahitza.setText("");
			tfIzena.setText("");
			tfKirola.setText("");
			tfJokalariKopurua.setText("");
			tfTaldeKopurua.setText("");

			
			
		} catch(Exception e) {
			
			JOptionPane.showMessageDialog(this, "Errorea " + e.getMessage() + " kluba sartzean: ", "Errorea", JOptionPane.ERROR_MESSAGE);
			
		}
		
	}
	
}
