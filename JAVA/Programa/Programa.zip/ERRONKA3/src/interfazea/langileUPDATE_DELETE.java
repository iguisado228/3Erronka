package interfazea;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import konexioa.konexioa;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class langileUPDATE_DELETE extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfId;
	private JTextField tfNAN;
	private JTextField tfIzena;
	private JTextField tfAbizena;
	private JTextField tfTelefonoa;
	private JTextField tfHelbidea;
	private JTextField tfLanPostua;
	private JTextField tfIdentifikadorea;
	private JTextField tfPasahitza;
	
	konexioa k = new konexioa();
	Connection conn = null; 
	ResultSet rs = null;
	PreparedStatement pst = null;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					langileUPDATE_DELETE frame = new langileUPDATE_DELETE();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public langileUPDATE_DELETE() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 986, 563);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblTestua = new JLabel("Sartu editatu edo ezabatu nahi duzun ID-a");
		lblTestua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTestua.setBounds(40, 38, 394, 40);
		panel.add(lblTestua);
		
		tfId = new JTextField();
		tfId.setColumns(10);
		tfId.setBounds(450, 38, 151, 34);
		panel.add(tfId);
		
		JButton btnEzabatu = new JButton("EZABATU");
		btnEzabatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ezabatuLangilea();
				
			}
		});
		btnEzabatu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEzabatu.setBounds(623, 38, 151, 34);
		panel.add(btnEzabatu);
		
		JButton btnEditatu = new JButton("EDITATU");
		btnEditatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aldatuLangilea();
			}
		});
		btnEditatu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEditatu.setBounds(794, 38, 151, 34);
		panel.add(btnEditatu);
		
		JLabel lblNAN = new JLabel("NAN");
		lblNAN.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNAN.setBounds(115, 125, 70, 34);
		panel.add(lblNAN);
		
		JLabel lblIzena = new JLabel("IZENA");
		lblIzena.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIzena.setBounds(115, 215, 70, 34);
		panel.add(lblIzena);
		
		JLabel lblAbizena = new JLabel("ABIZENA");
		lblAbizena.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblAbizena.setBounds(115, 305, 82, 34);
		panel.add(lblAbizena);
		
		JLabel lblTelefonoa = new JLabel("TELEFONOA");
		lblTelefonoa.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTelefonoa.setBounds(115, 400, 109, 34);
		panel.add(lblTelefonoa);
		
		JLabel lblHelbidea = new JLabel("HELBIDEA");
		lblHelbidea.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblHelbidea.setBounds(524, 125, 118, 34);
		panel.add(lblHelbidea);
		
		JLabel lblLanpostua = new JLabel("LANPOSTUA");
		lblLanpostua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblLanpostua.setBounds(524, 215, 133, 34);
		panel.add(lblLanpostua);
		
		JLabel lblIdentifikadorea = new JLabel("IDENTIFIKADOREA");
		lblIdentifikadorea.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIdentifikadorea.setBounds(524, 305, 188, 34);
		panel.add(lblIdentifikadorea);
		
		JLabel lblPasahitza = new JLabel("PASAHITZA");
		lblPasahitza.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPasahitza.setBounds(524, 400, 143, 34);
		panel.add(lblPasahitza);
		
		tfNAN = new JTextField();
		tfNAN.setColumns(10);
		tfNAN.setBounds(238, 125, 151, 34);
		panel.add(tfNAN);
		
		tfIzena = new JTextField();
		tfIzena.setColumns(10);
		tfIzena.setBounds(238, 215, 151, 34);
		panel.add(tfIzena);
		
		tfAbizena = new JTextField();
		tfAbizena.setColumns(10);
		tfAbizena.setBounds(238, 305, 151, 34);
		panel.add(tfAbizena);
		
		tfTelefonoa = new JTextField();
		tfTelefonoa.setColumns(10);
		tfTelefonoa.setBounds(238, 400, 151, 34);
		panel.add(tfTelefonoa);
		
		tfHelbidea = new JTextField();
		tfHelbidea.setColumns(10);
		tfHelbidea.setBounds(752, 125, 151, 34);
		panel.add(tfHelbidea);
		
		tfLanPostua = new JTextField();
		tfLanPostua.setColumns(10);
		tfLanPostua.setBounds(752, 215, 151, 34);
		panel.add(tfLanPostua);
		
		tfIdentifikadorea = new JTextField();
		tfIdentifikadorea.setColumns(10);
		tfIdentifikadorea.setBounds(752, 305, 151, 34);
		panel.add(tfIdentifikadorea);
		
		tfPasahitza = new JTextField();
		tfPasahitza.setColumns(10);
		tfPasahitza.setBounds(752, 400, 151, 34);
		panel.add(tfPasahitza);
		
		JButton btnAtzera = new JButton("ATZERA");
		btnAtzera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				langilePantaila lanP = new langilePantaila();
				lanP.setVisible(true);
				dispose();
				
			}
		});
		btnAtzera.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnAtzera.setBounds(752, 485, 151, 40);
		panel.add(btnAtzera);
		
		JButton btnOsatu = new JButton("OSATU");
		btnOsatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				bilatuLangilea();
				
			}
		});
		btnOsatu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnOsatu.setBounds(592, 485, 151, 40);
		panel.add(btnOsatu);
	}
	
	public void aldatuLangilea() {
		String idLangilea = tfId.getText();
		String NAN = tfNAN.getText();
		String izena = tfIzena.getText();
		String abizena = tfAbizena.getText();
		String telefonoa = tfTelefonoa.getText();
		String helbidea = tfHelbidea.getText();
		String lanpostua = tfLanPostua.getText();
		String identifikadorea = tfIdentifikadorea.getText();
		String pasahitza = tfPasahitza.getText();

		

		if (idLangilea.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Ez duzu aukerarik aukeratu", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			
		}
		try {
			
			int il = Integer.parseInt(idLangilea);
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql="update langilea set NAN=?, izena=?, abizena=?, telefonoa=?, helbidea=?, lanpostua=?, identifikadorea=?, pasahitza=? where idLangilea=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, NAN);
			pst.setString(2, izena);
			pst.setString(3, abizena);
			pst.setString(4, telefonoa);
			pst.setString(5, helbidea);
			pst.setString(6, lanpostua);
			pst.setString(7, identifikadorea);
			pst.setString(8, pasahitza);
			pst.setInt(9, il);
			pst.executeUpdate();
			
			tfNAN.setText(NAN);
			tfIzena.setText(izena);
			tfAbizena.setText(abizena);
			tfTelefonoa.setText(telefonoa);
			tfHelbidea.setText(helbidea);
			tfLanPostua.setText(lanpostua);
			tfIdentifikadorea.setText(identifikadorea);
			tfPasahitza.setText(pasahitza);
	
			JOptionPane.showMessageDialog(this, "Langilea ongi aldatu da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
			tfId.setText("");
			
		}catch(Exception e)  {
			JOptionPane.showMessageDialog(this, "Langilea aldatzean errore bat egon da.", "Errorea", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void ezabatuLangilea() {
		String idLangilea = tfId.getText();

		if (idLangilea.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Ez duzu aukerarik aukeratu", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			
		}
		try {
			
			int il = Integer.parseInt(idLangilea);
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql="delete from langilea where idLangilea=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, il);
			pst.executeUpdate();

			
			JOptionPane.showMessageDialog(this, "Langilea ongi ezabatu da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
			tfId.setText("");
			
		}catch(Exception e)  {
			JOptionPane.showMessageDialog(this, "Langilea ezabatzean errore bat egon da.", "Errorea", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void bilatuLangilea() {
	    String idLangilea = tfId.getText(); 

	    if (idLangilea.isEmpty()) {
	        JOptionPane.showMessageDialog(this, "Ez duzu ID bat sartu", "Errorea", JOptionPane.ERROR_MESSAGE);
	        return;
	    }

	    try {
	        int il = Integer.parseInt(idLangilea); 

	        Connection conn = konexioa.getConnection_(); 
	        String sql = "SELECT NAN, izena, abizena, telefonoa, helbidea, lanPostua, identifikadorea, pasahitza FROM langilea WHERE idLangilea=?"; 
	        PreparedStatement pst = conn.prepareStatement(sql);
	        pst.setInt(1, il);
	        ResultSet rs = pst.executeQuery(); 

	        if (rs.next()) { 
	        	
	        	tfNAN.setText(rs.getString("NAN"));
	        	tfIzena.setText(rs.getString("izena"));
	        	tfIdentifikadorea.setText(rs.getString("identifikadorea"));
	        	tfPasahitza.setText(rs.getString("pasahitza"));
	            tfTelefonoa.setText(rs.getString("telefonoa"));
	            tfHelbidea.setText(rs.getString("helbidea"));
	            tfLanPostua.setText(rs.getString("lanPostua"));
	            tfAbizena.setText(rs.getString("abizena"));

	        } else {
	            JOptionPane.showMessageDialog(this, "Ez da langilerik aurkitu ID honekin", "Abisua", JOptionPane.WARNING_MESSAGE);
	            tfIdentifikadorea.setText("");
	            tfPasahitza.setText("");
	            tfIzena.setText("");
	            tfAbizena.setText("");
	            tfNAN.setText("");
	            tfTelefonoa.setText("");
	            tfHelbidea.setText("");
	            tfLanPostua.setText("");
	          
	        }


	    } catch (NumberFormatException e) {
	        JOptionPane.showMessageDialog(this, "ID-a zenbaki bat izan behar da", "Errorea", JOptionPane.ERROR_MESSAGE);
	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this, "Errore bat gertatu da bilaketa egiterakoan", "Errorea", JOptionPane.ERROR_MESSAGE);
	    }
	}
	
}
