package interfazea;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.border.EmptyBorder;
import konexioa.konexioa;

public class sarreraAtera extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField tfIdLangilea;
    private JTextField tfPrezioa;
    private JComboBox<String> comboBox;
    
    konexioa k = new konexioa();
    Connection conn = null; 

//    public static void main(String[] args) {
//        EventQueue.invokeLater(() -> {
//            try {
//                sarreraAtera frame = new sarreraAtera();
//                frame.setVisible(true);
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        });
//    }

    public sarreraAtera() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1000, 600);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JLabel lblSarreraAteratzekoOndorengo = new JLabel("Sarrera ateratzeko ondorengo eremuak bete");
        lblSarreraAteratzekoOndorengo.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblSarreraAteratzekoOndorengo.setBounds(43, 38, 404, 40);
        contentPane.add(lblSarreraAteratzekoOndorengo);
        
        JLabel lblIdLangilea = new JLabel("ID LANGILEA");
        lblIdLangilea.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblIdLangilea.setBounds(115, 125, 126, 34);
        contentPane.add(lblIdLangilea);
        
        JLabel lblIdEremua = new JLabel("ID EREMUA");
        lblIdEremua.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblIdEremua.setBounds(115, 305, 113, 34);
        contentPane.add(lblIdEremua);
        
        JLabel lblPrezioa = new JLabel("PREZIOA");
        lblPrezioa.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblPrezioa.setBounds(524, 125, 113, 34);
        contentPane.add(lblPrezioa);
        
        tfIdLangilea = new JTextField();
        tfIdLangilea.setBounds(238, 125, 151, 34);
        contentPane.add(tfIdLangilea);
        
        tfPrezioa = new JTextField();
        tfPrezioa.setBounds(752, 125, 151, 34);
        contentPane.add(tfPrezioa);
        
        comboBox = new JComboBox<>(new String[]{"1 - Gimnasioa", "2 - Futbol-zelaiak", "3 - Igerileku estalia", "4 - Tenis-zelaiak", "5 - Eskubaloi-pista", "6 - Saskibaloi-pista", "7 - Atletismo-pista", "8 - Kanpoko saskibaloi-pista", "9 - Kanpoko eskubaloi-pista"});
        comboBox.setBounds(238, 305, 200, 34);
        contentPane.add(comboBox);
        
        JButton btnInsert = new JButton("INSERT");
        btnInsert.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnInsert.setBounds(623, 38, 151, 40);
        btnInsert.addActionListener(e -> insertSarrera());
        contentPane.add(btnInsert);
        
        JButton btnAtzera = new JButton("ATZERA");
        btnAtzera.addActionListener(e -> {
            sarreraPantaila sarP = new sarreraPantaila();
            sarP.setVisible(true);
            dispose();
        });
        btnAtzera.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnAtzera.setBounds(784, 38, 151, 40);
        contentPane.add(btnAtzera);
    }
    
    public void insertSarrera() {
        String idLangilea = tfIdLangilea.getText();
        String idEremua = (String) comboBox.getSelectedItem();
        String prezioa = tfPrezioa.getText();

        if (idLangilea.isEmpty() || idEremua == null || prezioa.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Eremu guztiak bete behar dira!", "Errorea", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        try {
            int il = Integer.parseInt(idLangilea);
            int ie = Integer.parseInt(idEremua.split(" - ")[0]); // Extrae el ID
            double p = Double.parseDouble(prezioa);
            
            conn = konexioa.getConnection_();
            String sql = "INSERT INTO sarrera (idLangilea, idEremua, prezioa) VALUES (?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, il);
            pst.setInt(2, ie);
            pst.setDouble(3, p);
            pst.executeUpdate();
            
            JOptionPane.showMessageDialog(this, "Sarrera ongi atera da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
            tfIdLangilea.setText("");
            comboBox.setSelectedIndex(-1);
            tfPrezioa.setText("");
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Errorea: ID eta Prezioa zenbakiak izan behar dira.", "Errorea", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Errorea datu-basean: " + e.getMessage(), "Errorea", JOptionPane.ERROR_MESSAGE);
        }
    }
}
