package interfazea;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import konexioa.konexioa;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class hornitzaileaUPDATE_DELETE extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfId;
	private JTextField tfCIF;
	private JTextField tfIzena;
	private JTextField tfTelefonoa;
	private JTextField tfHelbidea;
	
	konexioa k = new konexioa();
	Connection conn = null; 
	ResultSet rs = null;
	PreparedStatement pst = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					hornitzaileaUPDATE_DELETE frame = new hornitzaileaUPDATE_DELETE();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public hornitzaileaUPDATE_DELETE() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 986, 563);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblTestua = new JLabel("Sartu editatu edo ezabatu nahi duzun ID-a");
		lblTestua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTestua.setBounds(40, 38, 394, 40);
		panel.add(lblTestua);
		
		tfId = new JTextField();
		tfId.setColumns(10);
		tfId.setBounds(450, 38, 151, 34);
		panel.add(tfId);
		
		JButton btnEzabatu = new JButton("EZABATU");
		btnEzabatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ezabatuHornitzailea();
				
			}
		});
		btnEzabatu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEzabatu.setBounds(623, 38, 151, 34);
		panel.add(btnEzabatu);
		
		JButton btnEditatu = new JButton("EDITATU");
		btnEditatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aldatuHornitzailea();
			}
		});
		btnEditatu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEditatu.setBounds(794, 38, 151, 34);
		panel.add(btnEditatu);
		
		JLabel lblCIF = new JLabel("CIF");
		lblCIF.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblCIF.setBounds(115, 125, 70, 34);
		panel.add(lblCIF);
		
		tfCIF = new JTextField();
		tfCIF.setColumns(10);
		tfCIF.setBounds(238, 125, 151, 34);
		panel.add(tfCIF);
		
		JLabel lblIzena = new JLabel("IZENA");
		lblIzena.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIzena.setBounds(115, 305, 70, 34);
		panel.add(lblIzena);
		
		tfIzena = new JTextField();
		tfIzena.setColumns(10);
		tfIzena.setBounds(238, 305, 151, 34);
		panel.add(tfIzena);
		
		JLabel lblTelefonoa = new JLabel("TELEFONOA");
		lblTelefonoa.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTelefonoa.setBounds(524, 125, 122, 34);
		panel.add(lblTelefonoa);
		
		JLabel lblHelbidea = new JLabel("HELBIDEA");
		lblHelbidea.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblHelbidea.setBounds(524, 305, 109, 34);
		panel.add(lblHelbidea);
		
		tfTelefonoa = new JTextField();
		tfTelefonoa.setColumns(10);
		tfTelefonoa.setBounds(752, 125, 151, 34);
		panel.add(tfTelefonoa);
		
		tfHelbidea = new JTextField();
		tfHelbidea.setColumns(10);
		tfHelbidea.setBounds(752, 305, 151, 34);
		panel.add(tfHelbidea);
		
		JButton btnAtzera = new JButton("ATZERA");
		btnAtzera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				hornitzailePantaila horP = new hornitzailePantaila();
				horP.setVisible(true);
				dispose();
				
			}
		});
		btnAtzera.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnAtzera.setBounds(752, 485, 151, 40);
		panel.add(btnAtzera);
		
		JButton btnOsatu = new JButton("OSATU");
		btnOsatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				bilatuHornitzailea();
				
			}
		});
		btnOsatu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnOsatu.setBounds(592, 485, 151, 40);
		panel.add(btnOsatu);
	}
	
	public void aldatuHornitzailea() {
		String idHornitzailea = tfId.getText();
		String CIF = tfCIF.getText();
		String izena = tfIzena.getText();
		String telefonoa = tfTelefonoa.getText();
		String helbidea = tfHelbidea.getText();
		

		if (idHornitzailea.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Ez duzu aukerarik aukeratu", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			
		}
		try {
			
			int ih = Integer.parseInt(idHornitzailea);
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql="update hornitzailea set cif=?, izena=?, telefonoa=?, helbidea=? where idHornitzailea=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, CIF);
			pst.setString(2, izena);
			pst.setString(3,  telefonoa);
			pst.setString(4,  helbidea);
			pst.setInt(5, ih);
			pst.executeUpdate();
			
			tfCIF.setText(CIF);
			tfIzena.setText(izena);
			tfTelefonoa.setText(telefonoa);
			tfHelbidea.setText(helbidea);
		
			JOptionPane.showMessageDialog(this, "Hornitzailea ongi aldatu da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
			tfId.setText("");
			
		}catch(Exception e)  {
			JOptionPane.showMessageDialog(this, "Hornitzailea aldatzean errore bat egon da.", "Errorea", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void ezabatuHornitzailea() {
		String idHornitzailea = tfId.getText();

		if (idHornitzailea.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Ez duzu aukerarik aukeratu", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			
		}
		try {
			
			int ih = Integer.parseInt(idHornitzailea);
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql="delete from hornitzailea where idHornitzailea=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, ih);
			pst.executeUpdate();

			
			JOptionPane.showMessageDialog(this, "Hornitzailea ongi ezabatu da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
			tfId.setText("");
			
		}catch(Exception e)  {
			JOptionPane.showMessageDialog(this, "Hornitzailea ezabatzean errore bat egon da.", "Errorea", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void bilatuHornitzailea() {
	    String idHornitzailea = tfId.getText(); 

	    if (idHornitzailea.isEmpty()) {
	        JOptionPane.showMessageDialog(this, "Ez duzu ID bat sartu", "Errorea", JOptionPane.ERROR_MESSAGE);
	        return;
	    }

	    try {
	        int ih = Integer.parseInt(idHornitzailea); 

	        Connection conn = konexioa.getConnection_(); 
	        String sql = "SELECT CIF, izena, telefonoa, helbidea FROM hornitzailea WHERE idHornitzailea=?"; 
	        PreparedStatement pst = conn.prepareStatement(sql);
	        pst.setInt(1, ih);
	        ResultSet rs = pst.executeQuery(); 

	        if (rs.next()) { 
	            tfIzena.setText(rs.getString("izena"));
	            tfCIF.setText(rs.getString("CIF"));
	            tfTelefonoa.setText(rs.getString("telefonoa"));
	            tfHelbidea.setText(rs.getString("helbidea"));

	        } else {
	            JOptionPane.showMessageDialog(this, "Ez da hornitzailerik aurkitu ID honekin", "Abisua", JOptionPane.WARNING_MESSAGE);
	            tfIzena.setText("");
	            tfCIF.setText("");
	            tfTelefonoa.setText("");
	            tfHelbidea.setText("");
	          
	        }


	    } catch (NumberFormatException e) {
	        JOptionPane.showMessageDialog(this, "ID-a zenbaki bat izan behar da", "Errorea", JOptionPane.ERROR_MESSAGE);
	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this, "Errore bat gertatu da bilaketa egiterakoan", "Errorea", JOptionPane.ERROR_MESSAGE);
	    }
	}
	
}
