package interfazea;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class menuOrokorra extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					menuOrokorra frame = new menuOrokorra();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public menuOrokorra() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBounds(0, 0, 986, 563);
		contentPane.add(panel);
		
		JButton btnHornitzaileak = new JButton("HORNITZAILEAK");
		btnHornitzaileak.setIcon(new ImageIcon("C:\\xampp\\htdocs\\3Erronka\\JAVA\\Irudiak\\Hornitzaileak.png"));
		btnHornitzaileak.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				hornitzailePantaila horP = new hornitzailePantaila();
				horP.setVisible(true);
				dispose();
				
			}
		});
		btnHornitzaileak.setBounds(280, 319, 180, 180);
		panel.add(btnHornitzaileak);
		
		JButton btnMantenua = new JButton("MANTENUA");
		btnMantenua.setIcon(new ImageIcon("C:\\xampp\\htdocs\\3Erronka\\JAVA\\Irudiak\\Mantenua.png"));
		btnMantenua.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				mantenuaPantaila manP = new mantenuaPantaila();
				manP.setVisible(true);
				dispose();
				
			}
		});
		btnMantenua.setBounds(510, 319, 180, 180);
		panel.add(btnMantenua);
		
		JButton btnLangilea = new JButton("LANGILEAK");
		btnLangilea.setIcon(new ImageIcon("C:\\xampp\\htdocs\\3Erronka\\JAVA\\Irudiak\\Langileak.png"));
		btnLangilea.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				langilePantaila lanP = new langilePantaila();
				lanP.setVisible(true);
				dispose();
				
			}
		});
		btnLangilea.setBounds(280, 84, 180, 180);
		panel.add(btnLangilea);
		
		JButton btnKlubak = new JButton("KLUBAK");
		btnKlubak.setIcon(new ImageIcon("C:\\xampp\\htdocs\\3Erronka\\JAVA\\Irudiak\\Klubak.png"));
		btnKlubak.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				klubPantaila klubP = new klubPantaila();
				klubP.setVisible(true);
				dispose();
				
			}
		});
		btnKlubak.setBounds(57, 319, 180, 180);
		panel.add(btnKlubak);
		
		JButton btnObjetua = new JButton("OBJETUAK");
		btnObjetua.setIcon(new ImageIcon("C:\\xampp\\htdocs\\3Erronka\\JAVA\\Irudiak\\Objetuak.png"));
		btnObjetua.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				objetuPantaila objP = new objetuPantaila();
				objP.setVisible(true);
				dispose();
				
			}
		});
		btnObjetua.setBounds(510, 84, 180, 180);
		panel.add(btnObjetua);
		
		JButton btnBazkideak = new JButton("BAZKIDEAK");
		btnBazkideak.setIcon(new ImageIcon("C:\\xampp\\htdocs\\3Erronka\\JAVA\\Irudiak\\Bazkideak.png"));
		btnBazkideak.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				bazkidePantaila bazP = new bazkidePantaila();
				bazP.setVisible(true);
				dispose();
			}
		});
		btnBazkideak.setBounds(57, 84, 180, 180);
		panel.add(btnBazkideak);
		
		JButton btnSarrera = new JButton("SARRERAK");
		btnSarrera.setIcon(new ImageIcon("C:\\xampp\\htdocs\\3Erronka\\JAVA\\Irudiak\\Sarrerak.png"));
		btnSarrera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				sarreraPantaila sarP = new sarreraPantaila();
				sarP.setVisible(true);
				dispose();
				
			}
		});
		btnSarrera.setBounds(741, 319, 180, 180);
		panel.add(btnSarrera);
		
		JButton btnTaldeak = new JButton("TALDEAK");
		btnTaldeak.setIcon(new ImageIcon("C:\\xampp\\htdocs\\3Erronka\\JAVA\\Irudiak\\Taldeak.png"));
		btnTaldeak.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				taldeaPantaila talP = new taldeaPantaila();
				talP.setVisible(true);
				dispose();
				
			}
		});
		btnTaldeak.setBounds(741, 84, 180, 180);
		panel.add(btnTaldeak);
	}

}
