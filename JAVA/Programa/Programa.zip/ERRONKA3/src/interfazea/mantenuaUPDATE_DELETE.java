package interfazea;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import konexioa.konexioa;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class mantenuaUPDATE_DELETE extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfId;
	private JTextField tfIdLangilea;
	private JTextField tfIdEremua;
	private JTextField tfMota;
	private JTextField tfData;
	private JTextField tfEgoera;
	private JTextField tfBeharrekoa;
	
	konexioa k = new konexioa();
	Connection conn = null; 
	ResultSet rs = null;
	PreparedStatement pst = null;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					mantenuaUPDATE_DELETE frame = new mantenuaUPDATE_DELETE();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public mantenuaUPDATE_DELETE() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 986, 563);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblTestua = new JLabel("Sartu editatu edo ezabatu nahi duzun ID-a");
		lblTestua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTestua.setBounds(40, 38, 394, 40);
		panel.add(lblTestua);
		
		tfId = new JTextField();
		tfId.setColumns(10);
		tfId.setBounds(450, 38, 151, 34);
		panel.add(tfId);
		
		tfIdLangilea = new JTextField();
		tfIdLangilea.setColumns(10);
		tfIdLangilea.setBounds(238, 125, 151, 34);
		panel.add(tfIdLangilea);
		
		tfIdEremua = new JTextField();
		tfIdEremua.setColumns(10);
		tfIdEremua.setBounds(238, 215, 151, 34);
		panel.add(tfIdEremua);
		
		tfMota = new JTextField();
		tfMota.setColumns(10);
		tfMota.setBounds(238, 305, 151, 34);
		panel.add(tfMota);
		
		tfData = new JTextField();
		tfData.setColumns(10);
		tfData.setBounds(752, 125, 151, 34);
		panel.add(tfData);
		
		tfEgoera = new JTextField();
		tfEgoera.setColumns(10);
		tfEgoera.setBounds(752, 215, 151, 34);
		panel.add(tfEgoera);
		
		tfBeharrekoa = new JTextField();
		tfBeharrekoa.setColumns(10);
		tfBeharrekoa.setBounds(752, 305, 151, 34);
		panel.add(tfBeharrekoa);
		
		JButton btnEzabatu = new JButton("EZABATU");
		btnEzabatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ezabatuMantenua();
				
			}
		});
		btnEzabatu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEzabatu.setBounds(623, 38, 151, 34);
		panel.add(btnEzabatu);
		
		JButton btnEditatu = new JButton("EDITATU");
		btnEditatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aldatuMantenua();
			}
		
		});
		btnEditatu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEditatu.setBounds(784, 38, 151, 34);
		panel.add(btnEditatu);
		
		JButton btnAtzera = new JButton("ATZERA");
		btnAtzera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				mantenuaPantaila manP = new mantenuaPantaila();
				manP.setVisible(true);
				dispose();
				
			}
		});
		btnAtzera.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnAtzera.setBounds(752, 484, 151, 40);
		panel.add(btnAtzera);
		
		JLabel lblIdLangilea = new JLabel("ID LANGILEA");
		lblIdLangilea.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIdLangilea.setBounds(115, 125, 125, 40);
		panel.add(lblIdLangilea);
		
		JLabel lblIdEremua = new JLabel("ID EREMUA");
		lblIdEremua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIdEremua.setBounds(115, 215, 178, 40);
		panel.add(lblIdEremua);
		
		JLabel lblMota = new JLabel("MOTA");
		lblMota.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblMota.setBounds(115, 305, 178, 40);
		panel.add(lblMota);
		
		JLabel lblData = new JLabel("DATA");
		lblData.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblData.setBounds(524, 125, 178, 40);
		panel.add(lblData);
		
		JLabel lblEgoera = new JLabel("EGOERA");
		lblEgoera.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblEgoera.setBounds(524, 215, 178, 40);
		panel.add(lblEgoera);
		
		JLabel lblBeharrekoa = new JLabel("BEHARREKOA");
		lblBeharrekoa.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblBeharrekoa.setBounds(524, 305, 178, 40);
		panel.add(lblBeharrekoa);
		
		JButton btnOsatu = new JButton("OSATU");
		btnOsatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				bilatuMantenua();
				
			}
		});
		btnOsatu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnOsatu.setBounds(592, 484, 151, 40);
		panel.add(btnOsatu);
	}

	public void aldatuMantenua() {
		String idMantenua = tfId.getText();
		String idLangilea = tfIdLangilea.getText();
		String idEremua = tfIdEremua.getText();
		String mota = tfMota.getText();
		String data = tfData.getText();
		String egoera = tfEgoera.getText();
		String beharrekoa = tfBeharrekoa.getText();
		

		

		if (idLangilea.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Ez duzu aukerarik aukeratu", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			
		}
		try {
			
			int il = Integer.parseInt(idLangilea);
			int ie = Integer.parseInt(idEremua);
			int im = Integer.parseInt(idMantenua);
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql="update mantenua set idLangilea=?, idEremua=?, mota=?, data=?, egoera=?, beharrekoa=? where idMantenua=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, il);
			pst.setInt(2, ie);
			pst.setString(3, mota);
			pst.setString(4, data);
			pst.setString(5, egoera);
			pst.setString(6, beharrekoa);
			pst.setInt(7, im);
			pst.executeUpdate();
			
			
			tfIdLangilea.setText(idLangilea);
			tfIdEremua.setText(idEremua);
			tfMota.setText(mota);
			tfData.setText(data);
			tfEgoera.setText(egoera);
			tfBeharrekoa.setText(beharrekoa);

		
	
			JOptionPane.showMessageDialog(this, "Mantenua ongi aldatu da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
			tfId.setText("");
			
		}catch(Exception e)  {
			JOptionPane.showMessageDialog(this, "Mantenua aldatzean errore bat egon da.", "Errorea", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void ezabatuMantenua() {
		String idMantenua = tfId.getText();

		if (idMantenua.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Ez duzu aukerarik aukeratu", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			
		}
		try {
			
			int im = Integer.parseInt(idMantenua);
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql="delete from mantenua where idMantenua=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, im);
			pst.executeUpdate();

			
			JOptionPane.showMessageDialog(this, "Mantenua ongi ezabatu da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
			tfId.setText("");
			
		}catch(Exception e)  {
			JOptionPane.showMessageDialog(this, "Mantenua ezabatzean errore bat egon da.", "Errorea", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void bilatuMantenua() {
	    String idMantenua = tfId.getText(); 

	    if (idMantenua.isEmpty()) {
	        JOptionPane.showMessageDialog(this, "Ez duzu ID bat sartu", "Errorea", JOptionPane.ERROR_MESSAGE);
	        return;
	    }

	    try {
	        int im = Integer.parseInt(idMantenua); 

	        Connection conn = konexioa.getConnection_(); 
	        String sql = "SELECT idLangilea, idEremua, mota, data, egoera, beharrekoa FROM mantenua WHERE idMantenua=?"; 
	        PreparedStatement pst = conn.prepareStatement(sql);
	        pst.setInt(1, im);
	        ResultSet rs = pst.executeQuery(); 

	        if (rs.next()) { 
	        	
	        	tfIdLangilea.setText(rs.getString("idLangilea"));
	        	tfIdEremua.setText(rs.getString("idEremua"));
	        	tfMota.setText(rs.getString("mota"));
	        	tfData.setText(rs.getString("data"));
	            tfEgoera.setText(rs.getString("egoera"));
	            tfBeharrekoa.setText(rs.getString("beharrekoa"));

	        } else {
	            JOptionPane.showMessageDialog(this, "Ez da mantenurik aurkitu ID honekin", "Abisua", JOptionPane.WARNING_MESSAGE);
	            tfIdLangilea.setText("");
	            tfIdEremua.setText("");
	            tfMota.setText("");
	            tfData.setText("");
	            tfEgoera.setText("");
	            tfBeharrekoa.setText("");
	           
	          
	        }


	    } catch (NumberFormatException e) {
	        JOptionPane.showMessageDialog(this, "ID-a zenbaki bat izan behar da", "Errorea", JOptionPane.ERROR_MESSAGE);
	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this, "Errore bat gertatu da bilaketa egiterakoan", "Errorea", JOptionPane.ERROR_MESSAGE);
	    }
	}
	
}
