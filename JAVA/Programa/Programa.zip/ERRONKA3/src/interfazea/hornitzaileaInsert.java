package interfazea;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import konexioa.konexioa;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class hornitzaileaInsert extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfCIF;
	private JTextField tfIzena;
	private JTextField tfTelefonoa;
	private JTextField tfHelbidea;
	
	konexioa k = new konexioa();
	Connection conn = null; 
	ResultSet rs = null;
	PreparedStatement pst = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					hornitzaileaInsert frame = new hornitzaileaInsert();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public hornitzaileaInsert() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 986, 563);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblTestua = new JLabel("Ondorengo eremuak bete hornitzaile berriaren datuak sartzeko");
		lblTestua.setBounds(43, 38, 570, 25);
		lblTestua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		panel.add(lblTestua);
		
		JButton btnInsert = new JButton("INSERT");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				insertHornitzailea();
				
			}
		});
		btnInsert.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnInsert.setBounds(623, 30, 151, 40);
		panel.add(btnInsert);
		
		JLabel lblCIF = new JLabel("CIF");
		lblCIF.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblCIF.setBounds(115, 125, 70, 34);
		panel.add(lblCIF);
		
		JLabel lblIzena = new JLabel("IZENA");
		lblIzena.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIzena.setBounds(115, 305, 70, 34);
		panel.add(lblIzena);
		
		JLabel lblTelefonoa = new JLabel("TELEFONOA");
		lblTelefonoa.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTelefonoa.setBounds(524, 125, 122, 34);
		panel.add(lblTelefonoa);
		
		JLabel lblHelbidea = new JLabel("HELBIDEA");
		lblHelbidea.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblHelbidea.setBounds(524, 305, 109, 34);
		panel.add(lblHelbidea);
		
		tfCIF = new JTextField();
		tfCIF.setColumns(10);
		tfCIF.setBounds(238, 125, 151, 34);
		panel.add(tfCIF);
		
		tfIzena = new JTextField();
		tfIzena.setColumns(10);
		tfIzena.setBounds(238, 305, 151, 34);
		panel.add(tfIzena);
		
		tfTelefonoa = new JTextField();
		tfTelefonoa.setColumns(10);
		tfTelefonoa.setBounds(752, 125, 151, 34);
		panel.add(tfTelefonoa);
		
		tfHelbidea = new JTextField();
		tfHelbidea.setColumns(10);
		tfHelbidea.setBounds(752, 305, 151, 34);
		panel.add(tfHelbidea);
		
		JButton btnAtzera = new JButton("ATZERA");
		btnAtzera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				hornitzailePantaila horP = new hornitzailePantaila();
				horP.setVisible(true);
				dispose();
				
			}
		});
		btnAtzera.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnAtzera.setBounds(784, 30, 151, 40);
		panel.add(btnAtzera);
	}
	
public void insertHornitzailea() {
		
		String CIF = tfCIF.getText();
		String izena = tfIzena.getText();
		String telefonoa = tfTelefonoa.getText();
		String helbidea = tfHelbidea.getText();
		
		if(CIF.isEmpty() || izena.isEmpty() || telefonoa.isEmpty() || helbidea.isEmpty()) {
			
			JOptionPane.showMessageDialog(this, "Eremu guztiak bete behar dira!", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			return;
			
		}
		
		try {
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql = "insert into hornitzailea (cif, izena, telefonoa, helbidea) VALUES (?, ?, ?, ?)";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, CIF);
			pst.setString(2, izena);
			pst.setString(3, telefonoa);
			pst.setString(4, helbidea);
			pst.executeUpdate();
			
			JOptionPane.showMessageDialog(this, "Hornitzailea ongi gehitu da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
			tfCIF.setText("");
			tfIzena.setText("");
			tfTelefonoa.setText("");
			tfHelbidea.setText("");

			
			
		} catch(Exception e) {
			
			JOptionPane.showMessageDialog(this, "Errorea " + e.getMessage() + " hornitzailea sartzean: ", "Errorea", JOptionPane.ERROR_MESSAGE);
			
		}
		
	}

}
