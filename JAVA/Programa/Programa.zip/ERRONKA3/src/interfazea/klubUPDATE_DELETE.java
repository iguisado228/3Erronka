package interfazea;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import konexioa.konexioa;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class klubUPDATE_DELETE extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfId;
	private JTextField tfIdentifikadorea;
	private JTextField tfPasahitza;
	private JTextField tfIzena;
	private JTextField tfKirola;
	private JTextField tfJokalariKopurua;
	private JTextField tfTaldeKopurua;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					klubUPDATE_DELETE frame = new klubUPDATE_DELETE();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	konexioa k = new konexioa();
	Connection conn = null; 
	ResultSet rs = null;
	PreparedStatement pst = null;
	/**
	 * Create the frame.
	 */
	public klubUPDATE_DELETE() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 986, 563);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblTestua = new JLabel("Sartu editatu edo ezabatu nahi duzun ID-a");
		lblTestua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTestua.setBounds(40, 38, 394, 40);
		panel.add(lblTestua);
		
		tfId = new JTextField();
		tfId.setColumns(10);
		tfId.setBounds(450, 38, 151, 34);
		panel.add(tfId);
		
		tfIdentifikadorea = new JTextField();
		tfIdentifikadorea.setColumns(10);
		tfIdentifikadorea.setBounds(238, 125, 151, 34);
		panel.add(tfIdentifikadorea);
		
		tfPasahitza = new JTextField();
		tfPasahitza.setColumns(10);
		tfPasahitza.setBounds(238, 215, 151, 34);
		panel.add(tfPasahitza);
		
		tfIzena = new JTextField();
		tfIzena.setColumns(10);
		tfIzena.setBounds(238, 305, 151, 34);
		panel.add(tfIzena);
		
		tfKirola = new JTextField();
		tfKirola.setColumns(10);
		tfKirola.setBounds(752, 125, 151, 34);
		panel.add(tfKirola);
		
		tfJokalariKopurua = new JTextField();
		tfJokalariKopurua.setColumns(10);
		tfJokalariKopurua.setBounds(752, 215, 151, 34);
		panel.add(tfJokalariKopurua);
		
		tfTaldeKopurua = new JTextField();
		tfTaldeKopurua.setColumns(10);
		tfTaldeKopurua.setBounds(752, 305, 151, 34);
		panel.add(tfTaldeKopurua);
		
		JButton btnEzabatu = new JButton("EZABATU");
		btnEzabatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ezabatuKluba();
				
			}
		});
		btnEzabatu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEzabatu.setBounds(623, 38, 151, 34);
		panel.add(btnEzabatu);
		
		JButton btnEditatu = new JButton("EDITATU");
		btnEditatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aldatuKluba();
			}
		});
		btnEditatu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEditatu.setBounds(794, 38, 151, 34);
		panel.add(btnEditatu);
		
		JLabel lblIdentifikadorea = new JLabel("IDENTIFIKADOREA");
		lblIdentifikadorea.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIdentifikadorea.setBounds(61, 125, 191, 34);
		panel.add(lblIdentifikadorea);
		
		JLabel lblPasahitza = new JLabel("PASAHITZA");
		lblPasahitza.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPasahitza.setBounds(115, 215, 113, 34);
		panel.add(lblPasahitza);
		
		JLabel lblIzena = new JLabel("IZENA");
		lblIzena.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIzena.setBounds(115, 305, 70, 34);
		panel.add(lblIzena);
		
		JLabel lblKirola = new JLabel("KIROLA");
		lblKirola.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblKirola.setBounds(524, 125, 70, 34);
		panel.add(lblKirola);
		
		JLabel lblJokalariKopurua = new JLabel("JOKALARI KOPURUA");
		lblJokalariKopurua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblJokalariKopurua.setBounds(524, 215, 191, 34);
		panel.add(lblJokalariKopurua);
		
		JLabel lblTaldeKopurua = new JLabel("TALDE KOPURUA");
		lblTaldeKopurua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTaldeKopurua.setBounds(524, 305, 165, 34);
		panel.add(lblTaldeKopurua);
		
		JButton btnAtzera = new JButton("ATZERA");
		btnAtzera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				klubPantaila klubP = new klubPantaila();
				klubP.setVisible(true);
				dispose();
				
			}
		});
		btnAtzera.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnAtzera.setBounds(752, 485, 151, 40);
		panel.add(btnAtzera);
		
		JButton btnOsatu = new JButton("OSATU");
		btnOsatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				bilatuKluba();
				
			}
		});
		btnOsatu.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnOsatu.setBounds(592, 485, 151, 40);
		panel.add(btnOsatu);
	}
	
	public void aldatuKluba() {
		String idKluba = tfId.getText();
		String identifikadorea = tfIdentifikadorea.getText();
		String pasahitza = tfPasahitza.getText();
		String izena = tfIzena.getText();
		String kirola = tfKirola.getText();
		String jokalariKopurua = tfJokalariKopurua.getText();
		String taldeKopurua = tfTaldeKopurua.getText();
		

		if (idKluba.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Ez duzu aukerarik aukeratu", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			
		}
		try {
			
			int iK = Integer.parseInt(idKluba);
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql="update kluba set identifikadorea=?, pasahitza=?, izena=?, kirola=?, jokalariKopurua=?, taldeKopurua=? where idKluba=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, identifikadorea);
			pst.setString(2, pasahitza);
			pst.setString(3, izena);
			pst.setString(4,  kirola);
			pst.setString(5,  jokalariKopurua);
			pst.setString(6, taldeKopurua);
			pst.setInt(7, iK);
			pst.executeUpdate();

			
			tfIdentifikadorea.setText(identifikadorea);
			tfPasahitza.setText(pasahitza);
			tfIzena.setText(izena);
			tfKirola.setText(kirola);
			tfJokalariKopurua.setText(jokalariKopurua);
			tfTaldeKopurua.setText(taldeKopurua);
		
			JOptionPane.showMessageDialog(this, "Kluba ongi aldatu da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
			tfId.setText("");
			
		}catch(Exception e)  {
			JOptionPane.showMessageDialog(this, "Kluba aldatzean errore bat egon da.", "Errorea", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void ezabatuKluba() {
		String idKluba = tfId.getText();

		if (idKluba.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Ez duzu aukerarik aukeratu", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			
		}
		try {
			
			int ik = Integer.parseInt(idKluba);
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql="delete from kluba where idKluba=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, ik);
			pst.executeUpdate();

			
			JOptionPane.showMessageDialog(this, "Kluba ongi ezabatu da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
			tfId.setText("");
			
		}catch(Exception e)  {
			JOptionPane.showMessageDialog(this, "Kluba ezabatzean errore bat egon da.", "Errorea", JOptionPane.ERROR_MESSAGE);
		}
	}

	public void bilatuKluba() {
	    String idKluba = tfId.getText(); 

	    if (idKluba.isEmpty()) {
	        JOptionPane.showMessageDialog(this, "Ez duzu ID bat sartu", "Errorea", JOptionPane.ERROR_MESSAGE);
	        return;
	    }

	    try {
	        int ik = Integer.parseInt(idKluba); 

	        Connection conn = konexioa.getConnection_(); 
	        String sql = "SELECT identifikadorea, pasahitza, izena, kirola, jokalariKopurua, taldeKopurua FROM kluba WHERE idKluba=?"; 
	        PreparedStatement pst = conn.prepareStatement(sql);
	        pst.setInt(1, ik);
	        ResultSet rs = pst.executeQuery(); 

	        if (rs.next()) { 
	        	tfIdentifikadorea.setText(rs.getString("identifikadorea"));
	        	tfPasahitza.setText(rs.getString("pasahitza"));
	            tfIzena.setText(rs.getString("izena"));
	            tfKirola.setText(rs.getString("kirola"));
	            tfJokalariKopurua.setText(rs.getString("jokalariKopurua"));
	            tfTaldeKopurua.setText(rs.getString("taldeKopurua"));

	        } else {
	            JOptionPane.showMessageDialog(this, "Ez da klubik aurkitu ID honekin", "Abisua", JOptionPane.WARNING_MESSAGE);
	            tfIdentifikadorea.setText("");
	            tfPasahitza.setText("");
	            tfIzena.setText("");
	            tfKirola.setText("");
	            tfJokalariKopurua.setText("");
	            tfTaldeKopurua.setText("");
	          
	        }


	    } catch (NumberFormatException e) {
	        JOptionPane.showMessageDialog(this, "ID-a zenbaki bat izan behar da", "Errorea", JOptionPane.ERROR_MESSAGE);
	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this, "Errore bat gertatu da bilaketa egiterakoan", "Errorea", JOptionPane.ERROR_MESSAGE);
	    }
	}
	
}
