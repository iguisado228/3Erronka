package interfazea;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import bazkideak.bazkidea;
import bazkideak.bazkideaErakutsi;

import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

public class bazkidePantaila extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					bazkidePantaila frame = new bazkidePantaila();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	private void bazkideaKargatu() {
		
		bazkideaErakutsi bazkideakErakutsi = new bazkideaErakutsi();
		List <bazkidea> bazkideak = bazkideakErakutsi.bazkideaErakutsi();
		
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		model.setRowCount(0);
		
		for (bazkidea ba : bazkideak) {
			
			model.addRow(new Object[] {ba.getIdBazkidea(), ba.getNAN(), ba.getIzena(), ba.getAbizena(), ba.getTelefonoa(), 
					ba.getHelbidea(), ba.getIdentifikadorea(), ba.getPasahitza()
			});
			
		}
		
	}
	
	
	/**
	 * Create the frame.
	 */
	public bazkidePantaila() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 986, 563);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton btnUpdatedelete = new JButton("UPDATE/DELETE");
		btnUpdatedelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				bazkideUPDATE_DELETE bazUD = new bazkideUPDATE_DELETE();
				bazUD.setVisible(true);
				dispose();
				
			}
		});
		btnUpdatedelete.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnUpdatedelete.setBounds(191, 0, 184, 62);
		panel.add(btnUpdatedelete);
		
		JButton btnInsert = new JButton("INSERT");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				bazkideInsert bazI = new bazkideInsert();
				bazI.setVisible(true);
				dispose();
				
			}
		});
		btnInsert.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnInsert.setBounds(0, 0, 184, 62);
		panel.add(btnInsert);
		
		JButton btnAtzera = new JButton("ATZERA");
		btnAtzera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				menuOrokorra menO = new menuOrokorra();
				menO.setVisible(true);
				dispose();
				
			}
		});
		btnAtzera.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnAtzera.setBounds(800, 0, 184, 62);
		panel.add(btnAtzera);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 61, 984, 502);
		panel.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null, null}
			},
			new String[] {
				"idBazkidea", "NAN", "izena", "abizena", "telefonoa", "helbidea", "identifikadorea", "pasahitza"
			}
		));
		scrollPane.setViewportView(table);
		bazkideaKargatu();
	}
}
