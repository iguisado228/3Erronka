package interfazea;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import konexioa.konexioa;

import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class objetuaInsert extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfIdHornitzailea;
	private JTextField tfIdEremua;
	private JTextField tfIzena;
	private JTextField tfData;
	private JTextField tfPrezioa;

	konexioa k = new konexioa();
	Connection conn = null; 
	ResultSet rs = null;
	PreparedStatement pst = null;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					objetuaInsert frame = new objetuaInsert();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public objetuaInsert() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 986, 563);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton btnAtzera = new JButton("ATZERA");
		btnAtzera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				objetuPantaila objP = new objetuPantaila();
				objP.setVisible(true);
				dispose();
				
			}
		});
		btnAtzera.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnAtzera.setBounds(784, 38, 151, 40);
		panel.add(btnAtzera);
		
		JLabel lblTestua = new JLabel("Ondorengo eremuak bete objetu berriaren datuak sartzeko");
		lblTestua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTestua.setBounds(43, 38, 563, 40);
		panel.add(lblTestua);
		
		JButton btnInsert = new JButton("INSERT");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				insertObjetua();
				
			}
		});
		btnInsert.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnInsert.setBounds(623, 38, 151, 40);
		panel.add(btnInsert);
		
		JLabel lblIdHornitzailea = new JLabel("ID HORNITZAILEA");
		lblIdHornitzailea.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIdHornitzailea.setBounds(56, 125, 178, 40);
		panel.add(lblIdHornitzailea);
		
		JLabel lblId = new JLabel("ID EREMUA");
		lblId.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblId.setBounds(115, 215, 118, 40);
		panel.add(lblId);
		
		JLabel lblIzena = new JLabel("IZENA");
		lblIzena.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIzena.setBounds(115, 305, 66, 40);
		panel.add(lblIzena);
		
		JLabel lblData = new JLabel("DATA");
		lblData.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblData.setBounds(524, 125, 66, 40);
		panel.add(lblData);
		
		JLabel lblPrezioa = new JLabel("PREZIOA");
		lblPrezioa.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPrezioa.setBounds(524, 215, 118, 40);
		panel.add(lblPrezioa);
		
		tfIdHornitzailea = new JTextField();
		tfIdHornitzailea.setColumns(10);
		tfIdHornitzailea.setBounds(238, 125, 151, 34);
		panel.add(tfIdHornitzailea);
		
		tfIdEremua = new JTextField();
		tfIdEremua.setColumns(10);
		tfIdEremua.setBounds(238, 215, 151, 34);
		panel.add(tfIdEremua);
		
		tfIzena = new JTextField();
		tfIzena.setColumns(10);
		tfIzena.setBounds(238, 305, 151, 34);
		panel.add(tfIzena);
		
		tfData = new JTextField();
		tfData.setColumns(10);
		tfData.setBounds(752, 125, 151, 34);
		panel.add(tfData);
		
		tfPrezioa = new JTextField();
		tfPrezioa.setColumns(10);
		tfPrezioa.setBounds(752, 215, 151, 34);
		panel.add(tfPrezioa);
	}

public void insertObjetua() {
		
		String idHornitzailea = tfIdHornitzailea.getText();
		String idEremua = tfIdEremua.getText();
		String izena = tfIzena.getText();
		String data = tfData.getText();
		String prezioa = tfPrezioa.getText();
		
		
		if(idHornitzailea.isEmpty() || idEremua.isEmpty() || izena.isEmpty() || data.isEmpty() || prezioa.isEmpty()) {
			
			JOptionPane.showMessageDialog(this, "Eremu guztiak bete behar dira!", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			return;
			
		}
		
		try {
			
			int ih = Integer.parseInt(idHornitzailea);
			int ie = Integer.parseInt(idEremua);
			double p = Double.parseDouble(prezioa);
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql = "insert into materiala (idHornitzailea, idEremua, izena, data, prezioa) VALUES (?, ?, ?, ?, ?)";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, ih);
			pst.setInt(2, ie);
			pst.setString(3, izena);
			pst.setString(4, data);
			pst.setDouble(5, p);
			pst.executeUpdate();
			
			JOptionPane.showMessageDialog(this, "Materiala ongi gehitu da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
			tfIdHornitzailea.setText("");
			tfIdEremua.setText("");
			tfIzena.setText("");
			tfData.setText("");
			tfPrezioa.setText("");

			
			
		} catch(Exception e) {
			
			JOptionPane.showMessageDialog(this, "Errorea " + e.getMessage() + " materiala sartzean: ", "Errorea", JOptionPane.ERROR_MESSAGE);
			
		}
		
	}
	
}
