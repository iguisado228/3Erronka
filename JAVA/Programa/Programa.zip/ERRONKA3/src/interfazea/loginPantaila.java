package interfazea;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import langilea.langileKudeaketa;
import langilea.langilea;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JPasswordField;

public class loginPantaila extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfIdentifikadorea;
	private JPasswordField pfPasahitza;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					loginPantaila frame = new loginPantaila();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public loginPantaila() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1001, 601);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 10, 987, 554);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblIdentifikadorea = new JLabel("IDENTIFIKADOREA");
		lblIdentifikadorea.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblIdentifikadorea.setBounds(47, 115, 265, 68);
		panel.add(lblIdentifikadorea);
		
		tfIdentifikadorea = new JTextField();
		tfIdentifikadorea.setBounds(358, 136, 358, 43);
		panel.add(tfIdentifikadorea);
		tfIdentifikadorea.setColumns(10);
		
		JLabel lblPasahitza = new JLabel("PASAHITZA");
		lblPasahitza.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblPasahitza.setBounds(47, 244, 265, 68);
		panel.add(lblPasahitza);
		
		JButton btnSaioaHasi = new JButton("SAIOA HASI");
		btnSaioaHasi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sartu();
			}
		});
		btnSaioaHasi.setBackground(new Color(128, 128, 255));
		btnSaioaHasi.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnSaioaHasi.setBounds(358, 393, 358, 43);
		panel.add(btnSaioaHasi);
		
		JLabel lblLogoa = new JLabel("");
		lblLogoa.setIcon(new ImageIcon("C:\\xampp\\htdocs\\3Erronka\\JAVA\\Irudiak\\allurraldeLogo.jpg"));
		lblLogoa.setBounds(760, 10, 217, 200);
		panel.add(lblLogoa);
		
		pfPasahitza = new JPasswordField();
		pfPasahitza.setBounds(358, 265, 358, 43);
		panel.add(pfPasahitza);
	}
	public void sartu() {
	    String identifikadorea = tfIdentifikadorea.getText();
	    String pasahitza = pfPasahitza.getText();
	    int idLangilea = 0;

	    langileKudeaketa lanKudeatu = new langileKudeaketa();

	    langilea langilea2 = new langilea(identifikadorea, pasahitza, idLangilea);
	    langilea2.setLangileIdentifikadorea(identifikadorea);
	    langilea2.setPasahitza(pasahitza);


	    langilea lan = lanKudeatu.langileaLortu(langilea2);
	    System.out.println(lan);

	    if (lan != null) {
	        idLangilea = lan.getIdLangilea(); 


	        JOptionPane.showMessageDialog(contentPane, "Saioa hasi duzu. ID: " + idLangilea, "Saioa ondo hasita", JOptionPane.INFORMATION_MESSAGE);

	        menuOrokorra men = new menuOrokorra();
	        men.setVisible(true);
	        dispose();

	    } else {
	        JOptionPane.showMessageDialog(contentPane, "Gaizki joan da.", "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}
}
