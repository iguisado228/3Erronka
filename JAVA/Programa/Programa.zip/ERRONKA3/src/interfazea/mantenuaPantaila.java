package interfazea;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import mantenua.mantenua;
import mantenua.mantenuaErakutsi;


public class mantenuaPantaila extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					mantenuaPantaila frame = new mantenuaPantaila();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

private void mantenuaKargatu() {
		
		mantenuaErakutsi mantenuakErakutsi = new mantenuaErakutsi();
		List <mantenua> mantenuak = mantenuakErakutsi.mantenuaErakutsi();
		
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		model.setRowCount(0);
		
		for (mantenua ma : mantenuak) {
			
			model.addRow(new Object[] {ma.getIdMantenua(), ma.getIdLangilea(), ma.getIdEremua(), ma.getMota(), ma.getData(), ma.getEgoera(), ma.getBeharrekoa()
			});
		}
}
	
	/**
	 * Create the frame.
	 */
	public mantenuaPantaila() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 986, 563);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton btnInsert = new JButton("INSERT");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				mantenuaInsert manI = new mantenuaInsert();
				manI.setVisible(true);
				dispose();
				
			}
		});
		btnInsert.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnInsert.setBounds(0, 0, 184, 62);
		panel.add(btnInsert);
		
		JButton btnUpdatedelete = new JButton("UPDATE/DELETE");
		btnUpdatedelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				mantenuaUPDATE_DELETE manUD = new mantenuaUPDATE_DELETE();
				manUD.setVisible(true);
				dispose();
				
			}
		});
		btnUpdatedelete.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnUpdatedelete.setBounds(191, 0, 184, 62);
		panel.add(btnUpdatedelete);
		
		JButton btnAtzera = new JButton("ATZERA");
		btnAtzera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				menuOrokorra menO = new menuOrokorra();
				menO.setVisible(true);
				dispose();
				
			}
		});
		btnAtzera.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnAtzera.setBounds(800, 0, 184, 62);
		panel.add(btnAtzera);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 61, 986, 503);
		panel.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null}
			},
			new String[] {
				"idMantenua", "idLangilea", "idEremua", "mota", "data", "egoera", "beharrekoa"
			}
		));
		scrollPane.setViewportView(table);
		mantenuaKargatu();
	}
}
