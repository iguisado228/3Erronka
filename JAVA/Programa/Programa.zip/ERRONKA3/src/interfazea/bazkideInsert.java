package interfazea;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bazkideak.bazkidea;
import konexioa.konexioa;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class bazkideInsert extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfNAN;
	private JTextField tfIzena;
	private JTextField tfAbizena;
	private JTextField tfTelefonoa;
	private JTextField tfHelbidea;
	private JTextField tfIdentifikadorea;
	private JTextField tfPasahitza;
	
	konexioa k = new konexioa();
	Connection conn = null; 
	ResultSet rs = null;
	PreparedStatement pst = null;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					bazkideInsert frame = new bazkideInsert();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public bazkideInsert() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 986, 563);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblTestua = new JLabel("Ondorengo eremuak bete bazkide berriaren datuak sartzeko");
		lblTestua.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTestua.setBounds(43, 42, 563, 40);
		panel.add(lblTestua);
		
		JLabel lblIzena = new JLabel("IZENA");
		lblIzena.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIzena.setBounds(115, 215, 88, 40);
		panel.add(lblIzena);
		
		JLabel lblNAN = new JLabel("NAN");
		lblNAN.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNAN.setBounds(375, 127, 66, 40);
		panel.add(lblNAN);
		
		JLabel lblAbizena = new JLabel("ABIZENA");
		lblAbizena.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblAbizena.setBounds(115, 305, 88, 40);
		panel.add(lblAbizena);
		
		tfNAN = new JTextField();
		tfNAN.setColumns(10);
		tfNAN.setBounds(450, 127, 151, 34);
		panel.add(tfNAN);
		
		tfIzena = new JTextField();
		tfIzena.setColumns(10);
		tfIzena.setBounds(238, 215, 151, 34);
		panel.add(tfIzena);
		
		tfAbizena = new JTextField();
		tfAbizena.setColumns(10);
		tfAbizena.setBounds(238, 305, 151, 34);
		panel.add(tfAbizena);
		
		JLabel lblTelefonoa = new JLabel("TELEFONOA");
		lblTelefonoa.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTelefonoa.setBounds(115, 400, 129, 40);
		panel.add(lblTelefonoa);
		
		JLabel lblHelbidea = new JLabel("HELBIDEA");
		lblHelbidea.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblHelbidea.setBounds(524, 215, 129, 40);
		panel.add(lblHelbidea);
		
		JLabel lblIdentifikadorea = new JLabel("IDENTIFIKADOREA");
		lblIdentifikadorea.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblIdentifikadorea.setBounds(524, 305, 170, 40);
		panel.add(lblIdentifikadorea);
		
		JLabel lblPasahitza = new JLabel("PASAHITZA");
		lblPasahitza.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPasahitza.setBounds(524, 400, 129, 40);
		panel.add(lblPasahitza);
		
		tfTelefonoa = new JTextField();
		tfTelefonoa.setColumns(10);
		tfTelefonoa.setBounds(238, 400, 151, 34);
		panel.add(tfTelefonoa);
		
		tfHelbidea = new JTextField();
		tfHelbidea.setColumns(10);
		tfHelbidea.setBounds(752, 215, 151, 34);
		panel.add(tfHelbidea);
		
		tfIdentifikadorea = new JTextField();
		tfIdentifikadorea.setColumns(10);
		tfIdentifikadorea.setBounds(752, 305, 151, 34);
		panel.add(tfIdentifikadorea);
		
		tfPasahitza = new JTextField();
		tfPasahitza.setColumns(10);
		tfPasahitza.setBounds(752, 400, 151, 34);
		panel.add(tfPasahitza);
		
		JButton btnInsert = new JButton("INSERT");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				insertBazkidea();
				
			}
		});
		btnInsert.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnInsert.setBounds(623, 38, 151, 40);
		panel.add(btnInsert);
		
		JButton btnAtzera = new JButton("ATZERA");
		btnAtzera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				bazkidePantaila bazP = new bazkidePantaila();
				bazP.setVisible(true);
				dispose();
				
			}
		});
		btnAtzera.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnAtzera.setBounds(784, 38, 151, 40);
		panel.add(btnAtzera);
	}
	
	public void insertBazkidea() {
		
		String NANa = tfNAN.getText();
		String izena = tfIzena.getText();
		String abizena = tfAbizena.getText();
		String telefonoa = tfTelefonoa.getText();
		String helbidea = tfHelbidea.getText();
		String identifikadorea = tfIdentifikadorea.getText();
		String pasahitza = tfPasahitza.getText();
		
		if(NANa.isEmpty() || izena.isEmpty() || abizena.isEmpty() || telefonoa.isEmpty() || helbidea.isEmpty() || identifikadorea.isEmpty() ||
				 pasahitza.isEmpty()) {
			
			JOptionPane.showMessageDialog(this, "Eremu guztiak bete behar dira!", "Errore bat izan da", JOptionPane.ERROR_MESSAGE);
			return;
			
		}
		
		try {
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql = "insert into bazkidea (nan, izena, abizena, telefonoa, helbidea, identifikadorea, pasahitza) VALUES (?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, NANa);
			pst.setString(2, izena);
			pst.setString(3, abizena);
			pst.setString(4, telefonoa);
			pst.setString(5, helbidea);
			pst.setString(6, identifikadorea);
			pst.setString(7, pasahitza);
			pst.executeUpdate();
			
			JOptionPane.showMessageDialog(this, "Bazkidea ongi gehitu da!", "Ondo joan da", JOptionPane.INFORMATION_MESSAGE);
			tfNAN.setText("");
			tfIzena.setText("");
			tfAbizena.setText("");
			tfTelefonoa.setText("");
			tfHelbidea.setText("");
			tfIdentifikadorea.setText("");
			tfPasahitza.setText("");
			
			
		} catch(Exception e) {
			
			JOptionPane.showMessageDialog(this, "Errorea " + e.getMessage() + " bazkidea sartzean: ", "Errorea", JOptionPane.ERROR_MESSAGE);
			
		}
		
	}
	
}
