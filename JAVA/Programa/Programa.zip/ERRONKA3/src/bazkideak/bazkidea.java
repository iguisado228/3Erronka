package bazkideak;

public class bazkidea {

	private int idBazkidea;
	private String NAN;
	private String izena;
	private String abizena;
	private String telefonoa;
	private String helbidea;
	private String identifikadorea;
	private String pasahitza;
	

	public bazkidea(int idBazkidea, String NAN, String izena, String abizena, String telefonoa, String helbidea, String identifikadorea, String pasahitza) {
		
		this.idBazkidea=idBazkidea;
		this.NAN=NAN;
		this.izena=izena;
		this.abizena=abizena;
		this.telefonoa=telefonoa;
		this.helbidea=helbidea;
		this.identifikadorea=identifikadorea;
		this.pasahitza=pasahitza;
		
	}

	public int getIdBazkidea() {
		return idBazkidea;
	}

	public void setIdBazkidea(int idBazkidea) {
		this.idBazkidea = idBazkidea;
	}

	public String getNAN() {
		return NAN;
	}

	public void setNAN(String nAN) {
		NAN = nAN;
	}

	public String getIzena() {
		return izena;
	}

	public void setIzena(String izena) {
		this.izena = izena;
	}

	public String getAbizena() {
		return abizena;
	}

	public void setAbizena(String abizena) {
		this.abizena = abizena;
	}

	public String getTelefonoa() {
		return telefonoa;
	}

	public void setTelefonoa(String telefonoa) {
		this.telefonoa = telefonoa;
	}

	public String getHelbidea() {
		return helbidea;
	}

	public void setHelbidea(String helbidea) {
		this.helbidea = helbidea;
	}

	public String getIdentifikadorea() {
		return identifikadorea;
	}

	public void setIdentifikadorea(String identifikadorea) {
		this.identifikadorea = identifikadorea;
	}

	public String getPasahitza() {
		return pasahitza;
	}

	public void setPasahitza(String pasahitza) {
		this.pasahitza = pasahitza;
	}
	
}
