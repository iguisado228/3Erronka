package bazkideak;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import konexioa.konexioa;

public class bazkideaErakutsi {
	
	public List<bazkidea> bazkideaErakutsi(){
		
		List <bazkidea> bazkideak = new ArrayList<>();
		
		konexioa k = new konexioa();
		bazkidea bazkidea = null;
		Connection conn = null; 
		ResultSet rs = null;
		PreparedStatement pst = null;
		
		try {
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql = "select * from bazkidea";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			
			while (rs.next()) {
				
				bazkidea ba = new bazkidea (rs.getInt("idBazkidea"), rs.getString("NAN"), rs.getString("izena"),
						 rs.getString("abizena"), rs.getString("telefonoa"), rs.getString("helbidea"), 
						 rs.getString("identifikadorea"), rs.getString("pasahitza"));
				bazkideak.add(ba);
				
			}
			
		} catch(Exception e) {
			
			e.printStackTrace();
			System.out.println("Errore bat izan da select-a egiterakoan");
		}
		return bazkideak;
	}
	
	

}
