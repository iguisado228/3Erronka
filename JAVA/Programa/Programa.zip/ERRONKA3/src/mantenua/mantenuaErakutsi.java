package mantenua;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import konexioa.konexioa;


public class mantenuaErakutsi {
	
public List<mantenua> mantenuaErakutsi(){
		
		List <mantenua> mantenuak = new ArrayList<>();
		
		konexioa k = new konexioa();
		mantenua mantenua = null;
		Connection conn = null; 
		ResultSet rs = null;
		PreparedStatement pst = null;
		
		try {
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql = "select * from mantenua";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			
			while (rs.next()) {
				
				mantenua ma = new mantenua (rs.getInt("idMantenua"), rs.getInt("idLangilea"), rs.getInt("idEremua"),
						 rs.getString("mota"), rs.getDate("data"), rs.getString("egoera"), rs.getString("beharrekoa"));
				mantenuak.add(ma);
				
			}
			
		} catch(Exception e) {
			
			e.printStackTrace();
			System.out.println("Errore bat izan da select-a egiterakoan");
		}
		return mantenuak;
	}

	
}


