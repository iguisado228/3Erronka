package mantenua;

import java.util.Date;

public class mantenua {
	
	private int idMantenua;
	private int idLangilea;
	private int idEremua;
	private String mota;
	private Date data;
	private String egoera;
	private String beharrekoa;
	
	public mantenua (int idMantenua, int idLangilea, int idEremua, String mota, Date data, String egoera, String beharrekoa) {
		
		this.idMantenua=idMantenua;
		this.idLangilea=idLangilea;
		this.idEremua=idEremua;
		this.mota=mota;
		this.data=data;
		this.egoera=egoera;
		this.beharrekoa=beharrekoa;
		
	}

	public int getIdMantenua() {
		return idMantenua;
	}

	public void setIdMantenua(int idMantenua) {
		this.idMantenua = idMantenua;
	}

	public int getIdLangilea() {
		return idLangilea;
	}

	public void setIdLangilea(int idLangilea) {
		this.idLangilea = idLangilea;
	}

	public int getIdEremua() {
		return idEremua;
	}

	public void setIdEremua(int idEremua) {
		this.idEremua = idEremua;
	}

	public String getMota() {
		return mota;
	}

	public void setMota(String mota) {
		this.mota = mota;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public String getEgoera() {
		return egoera;
	}

	public void setEgoera(String egoera) {
		this.egoera = egoera;
	}

	public String getBeharrekoa() {
		return beharrekoa;
	}

	public void setBeharrekoa(String beharrekoa) {
		this.beharrekoa = beharrekoa;
	}

}
