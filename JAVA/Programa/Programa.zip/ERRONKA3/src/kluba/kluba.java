package kluba;

public class kluba {

	private int idKluba;
	private String identifikadorea;
	private String pasahitza;
	private String izena;
	private String kirola;
	private String jokalariKopurua;
	private String taldeKopurua;
	
	public kluba (int idKluba, String identifikadorea, String pasahitza, String izena, String kirola, String jokalariKopurua, String taldeKopurua) {
		
		this.idKluba=idKluba;
		this.identifikadorea=identifikadorea;
		this.pasahitza=pasahitza;
		this.izena=izena;
		this.kirola=kirola;
		this.jokalariKopurua=jokalariKopurua;
		this.taldeKopurua=taldeKopurua;
		
	}

	public int getIdKluba() {
		return idKluba;
	}

	public void setIdKluba(int idKluba) {
		this.idKluba = idKluba;
	}

	public String getIdentifikadorea() {
		return identifikadorea;
	}

	public void setIdentifikadorea(String identifikadorea) {
		this.identifikadorea = identifikadorea;
	}

	public String getPasahitza() {
		return pasahitza;
	}

	public void setPasahitza(String pasahitza) {
		this.pasahitza = pasahitza;
	}

	public String getIzena() {
		return izena;
	}

	public void setIzena(String izena) {
		this.izena = izena;
	}

	public String getKirola() {
		return kirola;
	}

	public void setKirola(String kirola) {
		this.kirola = kirola;
	}

	public String getJokalariKopurua() {
		return jokalariKopurua;
	}

	public void setJokalariKopurua(String jokalariKopurua) {
		this.jokalariKopurua = jokalariKopurua;
	}

	public String getTaldeKopurua() {
		return taldeKopurua;
	}

	public void setTaldeKopurua(String taldeKopurua) {
		this.taldeKopurua = taldeKopurua;
	}
	
}
