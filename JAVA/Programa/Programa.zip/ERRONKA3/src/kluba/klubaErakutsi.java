package kluba;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import konexioa.konexioa;

public class klubaErakutsi {
	
	public List<kluba> klubaErakutsi(){
		
		List <kluba> klubak = new ArrayList<>();
		
		konexioa k = new konexioa();
		kluba kluba = null;
		Connection conn = null; 
		ResultSet rs = null;
		PreparedStatement pst = null;
		
		try {
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql = "select * from kluba";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			
			while (rs.next()) {
				
				kluba kl = new kluba (rs.getInt("idKluba"), rs.getString("identifikadorea"), rs.getString("pasahitza"),
						 rs.getString("izena"), rs.getString("kirola"), rs.getString("jokalariKopurua"), 
						 rs.getString("taldeKopurua"));
				klubak.add(kl);
				
			}
			
		} catch(Exception e) {
			
			e.printStackTrace();
			System.out.println("Errore bat izan da select-a egiterakoan");
		}
		return klubak;
	}
	
	

}
