package konexioa;

import java.sql.Connection;
import java.util.Scanner;


public class APP {

	public static void main(String[] args) {

		konexioa k = new konexioa();
		Connection connection_ = k.getConnection_();
		
		

		
	}
}

