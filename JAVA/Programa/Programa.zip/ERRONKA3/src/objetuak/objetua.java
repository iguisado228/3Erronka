package objetuak;

import java.sql.Date;

public class objetua {

	private int idMateriala;
	private int idEremua;
	private int idHornitzailea;
	private String izena;
	private Date data;
	private double prezioa;
	
	public objetua (int idMateriala, int idHornitzailea, int idEremua, String izena, Date data, double prezioa) {
		
		this.idMateriala=idMateriala;
		this.idHornitzailea=idHornitzailea;
		this.idEremua=idEremua;
		this.izena=izena;
		this.data=data;
		this.prezioa=prezioa;
		
		
	}

	public int getIdMateriala() {
		return idMateriala;
	}

	public void setIdMateriala(int idMateriala) {
		this.idMateriala = idMateriala;
	}

	public int getIdEremua() {
		return idEremua;
	}

	public void setIdEremua(int idEremua) {
		this.idEremua = idEremua;
	}

	public int getIdHornitzailea() {
		return idHornitzailea;
	}

	public void setIdHornitzailea(int idHornitzailea) {
		this.idHornitzailea = idHornitzailea;
	}

	public String getIzena() {
		return izena;
	}

	public void setIzena(String izena) {
		this.izena = izena;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public double getPrezioa() {
		return prezioa;
	}

	public void setPrezioa(double prezioa) {
		this.prezioa = prezioa;
	}
	
}
