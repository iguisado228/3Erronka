package objetuak;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import konexioa.konexioa;

public class objetuaErakutsi {

public List<objetua> objetuaErakutsi(){
		
		List <objetua> objetuak = new ArrayList<>();
		
		konexioa k = new konexioa();
		objetua objetua = null;
		Connection conn = null; 
		ResultSet rs = null;
		PreparedStatement pst = null;
		
		try {
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql = "select * from materiala";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			
			while (rs.next()) {
				
				objetua obj = new objetua (rs.getInt("idMateriala"), rs.getInt("idHornitzailea"), rs.getInt("idEremua"),
						 rs.getString("izena"), rs.getDate("data"), rs.getDouble("prezioa"));
				objetuak.add(obj);
				
			}
			
		} catch(Exception e) {
			
			e.printStackTrace();
			System.out.println("Errore bat izan da select-a egiterakoan");
		}
		return objetuak;
	}

	
	
}
