/**
 * 
 */
/**
 * 
 */
module ERRONKA3 {
	requires java.desktop;
	requires java.sql;
	requires org.apache.pdfbox;
}