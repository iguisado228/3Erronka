package hornitzaileak;

public class hornitzailea {
	
	private int idHornitzailea;
	private String CIF;
	private String izena;
	private String telefonoa;
	private String helbidea;
	
	public hornitzailea(int idHornitzailea, String CIF, String izena, String telefonoa, String helbidea) {
		
		this.idHornitzailea=idHornitzailea;
		this.CIF=CIF;
		this.izena=izena;
		this.telefonoa=telefonoa;
		this.helbidea=helbidea;
		
	}

	public int getIdHornitzailea() {
		return idHornitzailea;
	}

	public void setIdHornitzailea(int idHornitzailea) {
		this.idHornitzailea = idHornitzailea;
	}

	public String getCIF() {
		return CIF;
	}

	public void setCIF(String cIF) {
		CIF = cIF;
	}

	public String getIzena() {
		return izena;
	}

	public void setIzena(String izena) {
		this.izena = izena;
	}

	public String getTelefonoa() {
		return telefonoa;
	}

	public void setTelefonoa(String telefonoa) {
		this.telefonoa = telefonoa;
	}

	public String getHelbidea() {
		return helbidea;
	}

	public void setHelbidea(String helbidea) {
		this.helbidea = helbidea;
	}

}
