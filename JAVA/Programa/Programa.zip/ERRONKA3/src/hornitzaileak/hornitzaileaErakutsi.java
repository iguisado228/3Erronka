package hornitzaileak;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import konexioa.konexioa;

public class hornitzaileaErakutsi {
	
public List<hornitzailea> hornitzaileaErakutsi(){
		
		List <hornitzailea> hornitzaileak = new ArrayList<>();
		
		konexioa k = new konexioa();
		hornitzailea hornitzailea = null;
		Connection conn = null; 
		ResultSet rs = null;
		PreparedStatement pst = null;
		
		try {
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql = "select * from hornitzailea";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			
			while (rs.next()) {
				
				hornitzailea ho = new hornitzailea (rs.getInt("idHornitzailea"), rs.getString("CIF"), rs.getString("izena"),
						 rs.getString("telefonoa"), rs.getString("helbidea"));
				hornitzaileak.add(ho);
				
			}
			
		} catch(Exception e) {
			
			e.printStackTrace();
			System.out.println("Errore bat izan da select-a egiterakoan");
		}
		return hornitzaileak;
	}

}
