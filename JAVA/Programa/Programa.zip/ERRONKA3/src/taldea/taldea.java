package taldea;

public class taldea {

	private int idTaldea;
	private int idKluba;
	private String kategoria;
	private int jokalariKopurua;
	
	public taldea (int idTaldea, int idKluba, String kategoria, int jokalariKopurua) {
		
		this.idTaldea=idTaldea;
		this.idKluba=idKluba;
		this.kategoria=kategoria;
		this.jokalariKopurua=jokalariKopurua;
		
	}

	public int getIdTaldea() {
		return idTaldea;
	}

	public void setIdTaldea(int idTaldea) {
		this.idTaldea = idTaldea;
	}

	public int getIdKluba() {
		return idKluba;
	}

	public void setIdKluba(int idKluba) {
		this.idKluba = idKluba;
	}

	public String getKategoria() {
		return kategoria;
	}

	public void setKategoria(String kategoria) {
		this.kategoria = kategoria;
	}

	public int getJokalariKopurua() {
		return jokalariKopurua;
	}

	public void setJokalariKopurua(int jokalariKopurua) {
		this.jokalariKopurua = jokalariKopurua;
	}

}
