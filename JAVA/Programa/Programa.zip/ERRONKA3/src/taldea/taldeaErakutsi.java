package taldea;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


import konexioa.konexioa;

public class taldeaErakutsi {

public List<taldea> taldeaErakutsi(){
		
		List <taldea> taldeak = new ArrayList<>();
		
		konexioa k = new konexioa();
		taldea taldea = null;
		Connection conn = null; 
		ResultSet rs = null;
		PreparedStatement pst = null;
		
		try {
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql = "select * from taldea";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			
			while (rs.next()) {
				
				taldea ta = new taldea (rs.getInt("idTaldea"), rs.getInt("idKluba"), rs.getString("kategoria"),
						 rs.getInt("jokalariKopurua"));
				taldeak.add(ta);
				
			}
			
		} catch(Exception e) {
			
			e.printStackTrace();
			System.out.println("Errore bat izan da select-a egiterakoan");
		}
		return taldeak;
	}

	
}
