package sarrera;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import konexioa.konexioa;

public class sarreraErakutsi {
	
public List <sarrera> sarreraErakutsi(){
		
		List <sarrera> sarrerak = new ArrayList<>();
		
		konexioa k = new konexioa();
		sarrera sarrera = null;
		Connection conn = null; 
		ResultSet rs = null;
		PreparedStatement pst = null;
		
		try {
			
			Connection connection_ = k.getConnection_();
			conn = konexioa.getConnection_();
			String sql = "select * from sarrera";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			
			while (rs.next()) {
				
				sarrera sa = new sarrera (rs.getInt("idSarrera"), rs.getInt("idLangilea"), rs.getInt("idEremua"),
						 rs.getDouble("prezioa"));
				sarrerak.add(sa);
				
			}
			
		} catch(Exception e) {
			
			e.printStackTrace();
			System.out.println("Errore bat izan da select-a egiterakoan");
		}
		return sarrerak;
	}

}
