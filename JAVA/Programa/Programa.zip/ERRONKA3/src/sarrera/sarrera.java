package sarrera;

public class sarrera {
	
	
	private int idSarrera;
	private int idLangilea;
	private int idEremua;
	private double prezioa;
	
	public sarrera(int idSarrera, int idLangilea, int idEremua, double prezioa) {
		
		this.idSarrera=idSarrera;
		this.idLangilea=idLangilea;
		this.idEremua=idEremua;
		this.prezioa=prezioa;
		
	}

	public int getIdSarrera() {
		return idSarrera;
	}

	public void setIdSarrera(int idSarrera) {
		this.idSarrera = idSarrera;
	}

	public int getIdLangilea() {
		return idLangilea;
	}

	public void setIdLangilea(int idLangilea) {
		this.idLangilea = idLangilea;
	}

	public int getIdEremua() {
		return idEremua;
	}

	public void setIdEremua(int idEremua) {
		this.idEremua = idEremua;
	}

	public double getPrezioa() {
		return prezioa;
	}

	public void setPrezioa(double prezioa) {
		this.prezioa = prezioa;
	}

}
